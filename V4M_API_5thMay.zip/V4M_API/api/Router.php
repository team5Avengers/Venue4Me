<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require '../vendor/autoload.php';
require "./src/loginAction.php";
require "./src/registrationAction.php";
require "./src/registrationVendorAction.php";
require "./src/vendorObjectAction.php";
require "./src/hallObjectAction.php";
require "./src/searchBookingsForVendor.php";
require "./src/vendorIndexAction.php";
require "./src/vendorBookingHistoryAction.php";
require "./src/vendorProfileAction.php";
require "./src/vendorApprovalListAction.php";
require "./src/updatevendorApprovalAction.php";
require "./src/listOfVendorsAction.php";

$app = new \Slim\App;
$app->post('/login', \loginAction::class);
$app->post('/registration', \registrationAction::class);
$app->post('/registrationVendor', \registrationVendorAction::class);
$app->post('/vendorObject', \vendorObjectAction::class);
$app->post('/hallObject', \hallObjectAction::class);
$app->post('/searchBookingsObject', \searchBookingsForVendor::class);
$app->post('/vendorIndexObject', \vendorIndexAction::class);
$app->post('/vendorBookingHistoryObject', \vendorBookingHistoryAction::class);
$app->post('/vendorProfileObject', \vendorProfileAction::class);
$app->get('/vendorApprovalListObject', \vendorApprovalListAction::class);
$app->post('/UpdatevendorApprovalObject', \updatevendorApprovalAction::class);
$app->get('/listOfVendorsObject', \listOfVendorsAction::class);
$app->run();