<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class updatevendorApprovalAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
			$conn=new dbConnection();
		    $connection=$conn->connect_db();
			$json = $request->getBody();
			$data = json_decode($json, TRUE);
			$stat=$data['action'];
			$uname=$data['uname'];
			$query="update `user_login` set `status`='$stat' where `username`='$uname'";
			if($connection->query($query)){
				 $res= "true";
				 } else {
					$res= "false";
				 }
			
			//$stmt = $connection->prepare($query);
		//	$stmt->bind_param("ss", $stat,$uname);
			//$stmt->execute();
			//$res = $stmt->get_result();
			/*$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				} */		
			return $res;
   }
}

?>