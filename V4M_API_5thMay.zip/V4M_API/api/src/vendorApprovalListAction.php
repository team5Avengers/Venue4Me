<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class vendorApprovalListAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
			$conn=new dbConnection();
		    $connection=$conn->connect_db();
			$query="SELECT id,username,status,usertype,created_on FROM `user_login` WHERE `status`='wait' and `usertype`='vendor'";
			$stmt = $connection->prepare($query);
			$stmt->execute();
			$res = $stmt->get_result();
			$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				}		
			return json_encode($row1);
   }
}

?>