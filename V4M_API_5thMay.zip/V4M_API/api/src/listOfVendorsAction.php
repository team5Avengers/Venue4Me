<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class listOfVendorsAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
			$conn=new dbConnection();
		    $connection=$conn->connect_db();
			$query="SELECT ul.id,ul.username,ul.status,ul.usertype,ul.created_on,v.contact FROM `user_login` ul , vendor v WHERE ul.status='active' and ul.usertype='vendor' and ul.username=v.vid";
			$stmt = $connection->prepare($query);
			$stmt->execute();
			$res = $stmt->get_result();
			$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				}		
			return json_encode($row1);
   }
}

?>