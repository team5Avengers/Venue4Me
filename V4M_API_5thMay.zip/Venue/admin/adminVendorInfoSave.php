<?PHP
require_once'connection.php';
$conn=new dbConnection();
$connection=$conn->connect_db();
$vid=$_POST['vid'];
$vname=$_POST['vname'];
$contact=$_POST['contact'];
$street1=$_POST['street1'];
$street2=$_POST['street2'];
$landmark=$_POST['landmark'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$postalcode=$_POST['postalcode'];
$latitude=$_POST['latitude'];
$longitude=$_POST['longitude'];
if($vid!=""&&$vid!=" "){
$query="update `vendor` set `vname`='$vname',`contact`='$contact' where vid='$vid'";
			if($connection->query($query)){
				 $res= "true"; 
				header("Location: ../adminVendorInfo.php?vid=$vid&status=$res");
				 } else {
					$res= "false";
					header("Location: ../adminVendorInfo.php?vid=$vid&status=$res");
				 }		
			//return $res;
}

?>