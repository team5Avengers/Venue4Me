<?PHP
require_once'connection.php';
$conn=new dbConnection();
$connection=$conn->connect_db();
$vid=$_POST['vid'];
$hid=$_POST['hid'];
$hname=$_POST['hname'];
$categary=$_POST['categary'];
$bookingAmount=$_POST['bookingAmount'];
$pricing=$_POST['pricing'];
$seating=$_POST['seating'];
$capacity=$_POST['capacity'];
$hsDesc=$_POST['hsDesc'];
$hDesc=$_POST['hDesc'];
$features=$_POST['features'];
$menu=$_POST['menu'];
$events=$_POST['events'];
$id;
$createdBy="admin";
$date;
if($vid!=""&&$vid!=" "){
	$query="insert into hall values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				$stmt = $connection->prepare($query);
			if($stmt){
				$stmt->bind_param("iiisssssssssssisi",$id,$vid,$hid,$hname,$categary,$bookingAmount,$pricing,$seating,$capacity,$hsDesc,$features,$menu,$events,$createdBy,$date,$createdBy,$date);
					$stmt->execute();
				    header("Location: ../adminVendorInfo.php?vid=$vid&status=$res"	);
				 } else {
					$res= "false";
					header("Location: ../adminVendorInfo.php?vid=$vid&status=$res");
				 }		
}


?>