<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
//use \registrationAction as registrationAction;
require '../vendor/autoload.php';
require "./src/loginAction.php";
require "./src/registrationAction.php";

$app = new \Slim\App;
$app->post('/login', \loginAction::class);
$app->post('/registration', \registrationAction::class);
$app->get('/filters', \filterAction::class); //{
		//$paramValue = $app->request()->params('categories');
        //$cat[] = split(",", $paramValue); 
		
        //return $this->response->withJson($todos);
//});
$app->run();