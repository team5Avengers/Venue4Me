<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class registrationAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		date_default_timezone_set('UTC');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$json = $request->getBody();
		$obj = json_decode($json, TRUE);
		$name= $obj["name"];
		$email= $obj["email"];
		$userType= $obj["userType"];
		$contact= $obj["contact"];
		$password =$obj["password"];
		$status ="wait";
		$custId=$email;
		$id="";
		$salt="";
		$date = date("Y-m-d H:i:s");
		$createdBy="self";
		//$date1=$date->date;
		try{
				$query="insert into customer values(?,?,?,?,?,?,?,?,?)";
				$stmt = $connection->prepare($query);
				if($stmt){
					$stmt->bind_param("isssssisi",$id,$custId,$name,$email,$contact,$createdBy,$date,$createdBy,$date);
					$stmt->execute();
					
					$sql="insert into user_login(id,username,pswd,salt,userType,status,created_by,created_on,updated_by,updated_on)values(?,?,?,?,?,?,?,?,?,?)";
					$sqlStmt = $connection->prepare($sql);
					if($sqlStmt){
						$sqlStmt->bind_param("issssssisi",$id,$email,$password,$salt,$userType,$status,$createdBy,$date,$createdBy,$date);
						$sqlStmt->execute();
					}else{
						$rolQuery="delete from customer where email=:emailId";
						$rolStmt = $connection->prepare($rolQuery);
						$rolStmt->bindParam("emailId", $email);
						$rolStmt->execute();
						return "Rolled Back.";
					}
				}
				$connection=null;
        return "OK";
		}catch(PDOException $e) {
			return json_encode($e->getMessage());
		}
		//return "OK";
   }
}

?>