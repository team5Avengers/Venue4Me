<?PHP session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Venue4ME</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="plugins/select2/select2.min.css">
  <link rel="stylesheet" href="plugins/bootstrap-slider/slider.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<!-- ADD THE CLASS fixed TO GET A FIXED HEADER AND SIDEBAR LAYOUT -->
<!-- the fixed layout is not compatible with sidebar-mini -->
<body class="hold-transition skin-blue-light fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="Home.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>V</b>4Me</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="images/v4me.png" style="height: 40px; widht: 250px" /></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 10 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 5 new members joined today
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Alexander Pierce</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  Alexander Pierce - Web Developer
                  <small>Member since Nov. 2012</small>
                </p>
              </li>
              <!-- Menu Body -->
              
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        <!--  <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li> -->
        </ul>
      </div>
    </nav>
  </header>

  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">FILTERS</li>
		
		<li class="treeview active">
          <a href="#">
            <i class="fa fa-location-arrow"></i>
            <span>Refine your search</span>
			<span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            <!--<span class="pull-right-container">
              <span class="label label-primary pull-right">4</span>
            </span>-->
          </a>
          <ul class="treeview-menu">
			<li>
				<div class="form-group">
                  <label>City:</label>
                  <select class="form-control" id="city" style="width: 95%;">
                    <option>Hyderabad</option>
                  </select>
                </div>
			</li>
            <li>
				<div class="form-group">
                <label>Locality:</label></br>
                <select class="form-control select2" id="locality" multiple="multiple" data-placeholder="Select Locality" style="width: 95%;">
                 <!-- <option>Banjara Hills</option>
                  <option>Jubilee Hills</option>
                  <option>Kukatpally</option>
                  <option>Bowenpally</option>
                  <option>Dilshuk Nagar</option>
                  <option>Lingampally</option>
                  <option>Nacharam</option> -->
                </select>
              </div>
			</li>
          </ul>
        </li>
		
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Categories</span>
			<span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            <!--<span class="pull-right-container">
              <span class="label label-primary pull-right">4</span>
            </span>-->
          </a>
          <ul class="treeview-menu">
            <li><input type="checkbox" name="cat[]" value="" id="bh"> Banquet Halls</li>
            <li><input type="checkbox" name="cat[]" value="" id="fh"> Function Halls</li>
            <li><input type="checkbox" name="cat[]" value="" id="gd"> Gardens</li>
			<li><input type="checkbox" name="cat[]" value="" id="ch"> Convention Halls</li>
			<li><input type="checkbox" name="cat[]" value="" id="tr"> Terrace/RoofTops</li>
			<li><input type="checkbox" name="cat[]" value="" id="rt"> Resorts</li>
          </ul>
        </li>
      <!--  <li>
          <a href="widgets.html">
            <i class="fa fa-th"></i> <span>Widgets</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green">new</small>
            </span>
          </a>
        </li> -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Features</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><input type="checkbox" value="" id="ac"> AC</li>
            <li><input type="checkbox" value="" id="nc"> Non AC</li>
            <li><input type="checkbox" value="" id="veg"> Veg</li>
			<li><input type="checkbox" value="" id="nv"> Non - Veg</li>
          </ul>
        </li>
        <li class="treeview" id="range">
          <a href="#">
            <i class="fa fa-inr"></i>
            <span>Price Range</span>
            <!--<span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span> -->
          </a>
			  <ul class="treeview-menu">
				<li><input type="checkbox" value="" id="r1"> Rs. 10000 - 50000</li>
				<li><input type="checkbox" value="" id="r2"> Rs. 50000 - 100000</li>
				<li><input type="checkbox" value="" id="r3"> Rs. 100000 - 200000</li>
				<li><input type="checkbox" value="" id="r4"> > Rs. 200000</li>
			  </ul>
        </li>
		
		<li class="treeview" id="plate">
          <a href="#">
            <i class="fa fa-inr"></i>
            <span>Price Range(per plate)</span>
            <!--<span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span> -->
          </a>
		  <ul class="treeview-menu">
            <li><input type="checkbox" value="" id="pr1"> Rs. 500 - 1000</li>
            <li><input type="checkbox" value="" id="pr2"> Rs. 1000 - 1500</li>
            <li><input type="checkbox" value="" id="pr3"> Rs. 1500 - 2000</li>
			<li><input type="checkbox" value="" id="pr4"> > Rs. 2000</li>
          </ul>
        </li>
    </ul>
    <!-- /.sidebar -->
	</section>
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of Venues found.
        <small>100 venues found in your area.</small>
      </h1>
      <!--<ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Layout</a></li>
        <li class="active">Fixed</li>
      </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
    <?PHP
      if(isset($_SESSION['halls']))
			{	
				$halls=$_SESSION['halls'];
            }
        foreach($halls as $hall){
    ?>
	  <div class="box box-default">
          <div class="box-header with-border">
            <h3 class="box-title"><?PHP echo $hall->hname; ?></h3>
          </div>
          <div class="box-body no-padding">
			
			<table class="table table-condensed no-border">
                <tr>
					<td rowspan="3"> <img src="<?PHP echo $hall->photos; ?>" alt="Image1" style="height: 100px;width: 150px" /></td>
					<td align="left"><?PHP echo $hall->hall_shortdesc; ?></td>
					<td><div class="box-tools pull-right">
							<h4>Price: Rs.<?PHP echo $hall->booking_amt; ?></h4>
					</div></td>
				</tr>
				<tr>
					<td></td>
					<td><div class="box-tools pull-right">
							<a href="venue.html?id="<?PHP echo $hall->hid; ?>><button type="button" class="btn bg-orange" title="Collapse">Check Availability</button></a>
						</div></td>
				</tr>
           </table>
          </div>
	  </div>
        <?PHP } ?>
      <!-- /.box -->
	<!--<div class="box box-default">
        <div class="box-header with-border">
		  <h3 class="box-title">Cherukuri Function Hall, Main Rd, Kukatpally</h3>
        </div>
        <div class="box-body no-padding">
			<table class="table table-condensed no-border">
                <tr>
					<td rowspan="3"> <img src="images/img2.jpg" alt="Image1" style="height: 100px;width: 150px" /></td>
					<td align="left">This hall has state of the art architecture and spacing, best suited for Weddings.</td>
					<td><div class="box-tools pull-right">
							<h4>Price: Rs. 2,00,000</h4>
					</div></td>
				</tr>
				<tr>
					<td></td>
					<td><div class="box-tools pull-right">
							<a href="venue.html"><button type="button" class="btn bg-orange" title="Collapse">Check Availability</button></a>
						</div></td>
				</tr>
           </table>
        </div>
    </div>
	  
	  <div class="box box-default">
        <div class="box-header with-border">
		  <h3 class="box-title">JK Gardens, Main Rd, Kukatpally</h3>
        </div>
        <div class="box-body">
		<table class="table table-condensed no-border">
                <tr>
					<td rowspan="3"> <img src="images/img3.jpg" alt="Image1" style="height: 100px;width: 150px" /></td>
					<td align="left">This hall has state of the art architecture and spacing, best suited for Weddings.</td>
					<td><div class="box-tools pull-right">
							<h4>Price: Rs. 1,50,000</h4>
					</div></td>
				</tr>
				<tr>
					<td></td>
					<td><div class="box-tools pull-right">
							<a href="venue.html"><button type="button" class="btn bg-orange" title="Collapse">Check Availability</button></a>
						</div></td>
				</tr>
           </table>
        </div>
      </div> -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="container" align="center">
      <strong>Copyright &copy; 2017 <a href="#">Venue4Me</a>.</strong> All rights
      reserved.
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="dist/js/filter.js"></script>
<script src="plugins/select2/select2.full.min.js"></script>
<script src="plugins/bootstrap-slider/bootstrap-slider.js"></script>
<script>
  $(function () {
    /* BOOTSTRAP SLIDER */
    $('.slider').slider();
	$(".select2").select2();
  });
  
</script>
</body>
</html>
