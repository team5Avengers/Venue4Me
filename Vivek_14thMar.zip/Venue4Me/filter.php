<?PHP	
//$userName="Aviansh";
  //$locality = $_GET['locality'];
  $route = $_GET['id'];
  if($route=="select"){
    $url ='http://localhost:8020/localities';    
  }
  //$url ='http://localhost:8020/filters?locality=Champapet&categories=Banqu,Funct&events=Wedding';
  $ch = curl_init($url);
    //curl_setopt($ch, CURLOPT_GET, true)
    $out=curl_exec($ch);
    //echo $out;
    curl_close($ch);		  
?>