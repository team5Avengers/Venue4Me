<?PHP
require_once'./restHandlers/customerHomeRestHandler.php';
$ven=new customerHomeRestHandler();
$venObj=$ven->getCities();
$venArr=json_decode($venObj,true);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Venue4ME</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <script type="text/javascript" src="//code.jquery.com/jquery-2.0.2.js"></script>  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min1.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<style>
 .search-bar{

position: relative;
float: left;
width:150px;
 }
 .search-bar-position{
 margin-left:28%;
 
 }
 .box-searchbar {
     position:relative;
    border-radius: 3px;
    margin-bottom: 20px;
    width: 90%;
    padding-left: 0px;
}
.content-search-bar{
    min-height: 300px;
    padding: 15px;
    margin-right: auto;
    padding-left: 15px;
    padding-right: 15px;
}
#x{margin-top:16%;
  font-family: "Lucida Console", Monaco, monospace;
}
.divider
	{height:2px;
	width:100%;
	display:block;
	margin:9px 0;
	overflow:hidden;
	background-color:#f8c79e}
    
    .carousel-inner > .item > img,
.carousel-inner > .item > a > img {
    height:400px;
    width:100%;

}
    .transparent-input {
   background-color: rgba(0, 0, 0, 0.4);
   border:none;
}
    
    .main-header{
        position: fixed;
    }
    
    .descpoints{
        font-family:Trebuchet MS;
        margin-left:15%;
    }
    .descpoints .dphead{
        margin-left:35%;
        font-size: 20px;
        font-family: Trebuchet MS; 
    }
</style>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
      
    <script>
function scrollWin() {
    
    window.scrollTo(100, 400);
}
</script>
    
    
      <style type="text/css">
    .carousel-inner .active.left  { left: -33%;             }
.carousel-inner .active.right { left: 33%;              }
.carousel-inner .next         { left: 33%               }
.carousel-inner .prev         { left: -33%              }
.carousel-control.left        { background-image: none; }
.carousel-control.right       { background-image: none;er .item         { background: white;      }
      
}
input.form-control::-webkit-input-placeholder { font-size: 16pt; color: #555; }
input.form-control::-moz-placeholder { font-size: 16pt; color: #555; }
:-ms-input-placeholder { font-size: 16pt; color: #555; }
input:-moz-placeholder { font-size: 16pt; color: #555; }
input.myClassNameOne::-webkit-input-placeholder { 
    font-size: 16pt; color: #555;
}

/* Mozilla Firefox 4 to 18 */
input.myClassNameOne:-moz-placeholder { 
    font-size: 16pt; color: #555;
}

/* Mozilla Firefox 19+ */
input.myClassNameOne::-moz-placeholder { 
    font-size: 16pt; color: #555;
}

/* Internet Explorer 10+ */
input.myClassNameOne:-ms-input-placeholder {
    font-size: 16pt; color: #555;
}
          input[type='date']:after {
  content: attr(placeholder)
}
  </style>


<script type='text/javascript'>//<![CDATA[
$(window).load(function(){
$('#myCarousel').carousel({
  interval: 10000
})

$('.jc .carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
 
});
});
    
$(window).load(function(){
$('#myCarousel1').carousel({
  interval: 6000
})

$('.jc1 .carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
 
});
});//]]>
    
$(window).load(function(){
$('#myCarousel2').carousel({
  interval: 6000
})

$('.jc2 .carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
 
});
});//]]> 
    
$(window).load(function(){
$('#myCarousel3').carousel({
  interval: 6000
})

$('.jc3 .carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
 
});
});//]]>  

</script>
</head>
<body class="hold-transition skin-blue sidebar-mini">

  <header class="main-header">
    <!-- Logo -->
    <a href="Home.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>VENUE</b>4 ME</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-fixed-top">
      <!-- Sidebar toggle button-->


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
            
          <li class="dropdown messages-menu">
            <a data-target="#myModal" data-toggle="modal" class="MainNavText" id="MainNavHelp" href="#myModal">
              <i class="fa fa-sign-in">&nbsp;&nbsp;Sign-in</i>
            </a>
        
            </li>
           <li class="dropdown messages-menu">
            <a data-target="#myModal1" data-toggle="modal" class="MainNavText" id="MainNavHelp" href="#myModal">
              <i class="fa fa-sign-in">&nbsp;&nbsp;Register</i>
            </a>
          </li>
		
          </ul>
      </div>
    </nav>
  </header>
    <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content -->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Registration Window</h4>
      </div>
      <div class="modal-body">
              <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Login" data-toggle="tab">Login</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login" style="margin-top:1%;">
                                <form role="form" class="form-horizontal" action="core/authentication.php" method="post">
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Username</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="mailid" class="form-control" id="email1" placeholder="Enter Register Mobile No ( or ) E-Mail ID" autocomplete="off"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" name="password" class="form-control" id="exampleInputPassword1" autocomplete="off" placeholder="password" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit"  name="login" value="login"  class="btn btn-primary btn-sm">
                                            Submit</button>
                                        <a href="forgot-email.php">Forgot your password?</a>
                                    </div>
                                </div>
                                </form>
                            </div>
                            
                        </div>
                       
                    </div>
                 
                </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
    
      <div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">

   <!--  Modal content -->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Signin Window</h4>
      </div>
      <div class="modal-body">
              <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Registration" data-toggle="tab">Registration</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Registration" style="margin-top:1%;">
                                <form role="form" action="core/controller.php" method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <select class="form-control" name="salutation">
                                                    <option value="Mr">Mr.</option> 
                                                    <option value="Ms">Ms.</option>
                                                    <option value="Mrs">Mrs.</option>
                                                </select>
                                            </div>
                                            <div class="col-md-9">
                                                <input type="text" name="username" class="form-control" placeholder="Name" required autocomplete="off" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        E-Mail</label>
                                    <div class="col-sm-10">
                                        <input type="email" name="email"  required class="form-control" id="email" placeholder="Email" autocomplete="off" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="mobile" class="col-sm-2 control-label">
                                        Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="mobile" name="mobilenumber" required placeholder="Mobile" autocomplete="off" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" name="password" required id="password" autocomplete="off" placeholder="Password" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-10">
                                        <button type="submit" name="add_user" value="add"  class="btn btn-primary btn-sm">
                                            Save & Continue</button>
                                        <button type="button" class="btn btn-default btn-sm">
                                            Cancel</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                       
                    </div>
                 
                </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
 
  <!-- Left side column. contains the logo and sidebar -->
  <!-- Content Wrapper. Contains page content -->
    <br><br>
     <form class="form-horizontal" id="search_home" method="post" name="search_home">
          <div style="background:#ecf0f5">	    
                  <div class="box-body">

                     <div class="col-md-3 col-sm-push-4 has-feedback" style="margin-top:1%;">
                       <select class="form-control" id="city" name="place" placeholder="Location">
                       <option selected disabled>Location</option>
                       <?PHP 
                           foreach($venArr as $item) {
                               ?>
                            <option><?PHP echo $item['city'];?></option>
                        <?PHP }?>
                       </select>
                      </div>
                  </div>
          </div>

            <div class="content-wrapper">
                <section class="content-search-bar" style="margin-top:-10px;">

                   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                              <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                              <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                              <div class="item active">
                                <img src="images\banner1.jpg" alt="First slide">
                                <div class="carousel-caption"><marquee direction="right"><h3>ABCD</h3></marquee></div>
                              </div>
                              <div class="item">
                                <img src="images\banner03.jpg" alt="Second slide">
                                <div class="carousel-caption"><marquee direction="right"><h3>ABCD</h3></marquee></div>
                              </div>
                              <div class="item">
                                <img src="images\banner2.jpg" alt="Third slide">
                                <div class="carousel-caption"><marquee direction="right"><h3>ABCD</h3></marquee></div>
                              </div>
                              <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="fa fa-angle-left"></span>
                              </a>
                              <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="fa fa-angle-right"></span>
                              </a>
                            </div>
                    </div>

                 </section>

                <div class="box-searchbar col-sm-push-1 border-0">
                          <div class="row">

                              <div class="col-md-2 has-feedback">
                                <select class="form-control rounden-top" id="area" name="place" placeholder="Area">
                                      <i class="glyphicon glyphicon-map-marker form-control-feedback"></i>
                                    <option selected disabled>Select Area</option>
                                </select>

                              </div>
                            <div class="col-md-2">
                                <input type="date"  class="form-control" id="date" name="date" >
                            </div>


                            <div class="col-md-2">
                                <select class="form-control" id="type" name="type">
                                <option selected disabled>Looking For</option>
                                <option>Venue</option>
                                <option>Photographer</option>
                                <option>Catering</option>
                                <option>Decorator</option>
                                <option>Event Manager</option>
                                </select>
                            </div> 


                              <div class="col-md-2">
                                <select class="form-control" id="cat" name="category" placeholder="Event Type">
                                    <option selected disabled>Category</option>
                                </select>

                              </div>


                                <div class="col-md-2">
                                <select class="form-control" id="place" name="pacs" placeholder="Guest count">
                                <option selected disabled>Guest Count</option>
                                    <option>1-300</option>
                                    <option>301-500</option>
                                    <option>500-1000</option>
                                    <option>>1000</option>
                                </select>
                              </div>
                            </div>


                             <!-- <input type="submit" value="Search"> -->
                              <div class="row">
                                <div class="col-md-2 col-sm-push-4" style="margin-top:2%;">
                              <button type="submit" class="btn btn-info btn-block"><b>Search</b></button>
                                    </div>  
                              </div>
             </div> 
         </div>
    </form>
    
          <!-- /.box -->
 
		 <div class="row" style="margin-top:2%;">
		<div class="col-sm-6">
			<h2>&nbsp;&nbsp;Featured Venues</h2>
	<div class="divider"></div>
			<div class="jc">
	  <div id="myCarousel" class="carousel slide">  
	  <div class="carousel-inner">
		<div class="item active">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
	   
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
	</div>
				</div>
			</div>
			<div class="col-sm-6">
	   <h2>&nbsp;&nbsp;Featured Decorators</h2>
	<div class="divider"></div>
	  <div class="jc1">
	<div id="myCarousel1" class="carousel slide">
	  <div class="carousel-inner">
		 <div class="item active">
		  <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		  <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		   <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
		  </div>
				</div>
	</div>
			</div>
		 <div class="row">
		<div class="col-sm-6">
			<h2>&nbsp;&nbsp;Featured Photographers</h2>
	<div class="divider"></div>
			<div class="jc2">
	  <div id="myCarousel2" class="carousel slide">  
	  <div class="carousel-inner">
		<div class="item active">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
	   
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
	</div>
				</div>
			</div>
			<div class="col-sm-6">
	   <h2>&nbsp;&nbsp;Featured Makeup Artists</h2>
	<div class="divider"></div>
	  <div class="jc3">
	<div id="myCarousel3" class="carousel slide">
	  <div class="carousel-inner">
		 <div class="item active">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
		<div class="item">
		    <div class="col-lg-6 col-xs-12" >
              <a href="#">
                  <div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
                      <div class="inner" style="color:white;height:150px;">
                          <h4>Cherukuri Function Hall &nbsp;&nbsp;&nbsp;&nbsp;
                              <a href="">
                                  <i class="fa fa-heart-o" aria-hidden="true">
                                  </i>
                              </a>
                          </h4>
                      </div>
                      <a href="#" class="small-box-footer"style="color:white;">More info 
                          <i class="fa fa-arrow-circle-right">
                          </i>
                      </a>
                  </div>
              </a>
             </div>
		</div>
	  </div>

	  <!-- Controls -->
	  <a class="left carousel-control" href="#myCarousel3" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#myCarousel3" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
		  </div>
				</div>
	</div>
			</div><!--<div class="row">
    <div class="col-sm-6">
        <h2>&nbsp;&nbsp;Featured Photographers</h2>
<div class="divider"></div>
        </div>
       
        </div> -->
        
  <!-- <div class="row" style="margin-top:10%;">
      
          <div class="col-md-3 col-sm-push-1">
            <div class="descpoints">
               <div class="dphead">Services</div>
                                <div class="divider"></div> 

                <div class="dpsubhead">With GiftMyShow cards, you can gift your friends & family movie & play tickets, concert passes, whatever it is they love for their birthdays, anniversaries or simply for no reason other than how you feel about them. Pretty sweet, aint it?</div>
              </div>
          </div>  
           <div class="col-md-3 col-sm-push-1">
            <div class="descpoints">
               <div class="dphead">Offers</div>
                                <div class="divider"></div> 

                <div class="dpsubhead">With GiftMyShow cards, you can gift your friends & family movie & play tickets, concert passes, whatever it is they love for their birthdays, anniversaries or simply for no reason other than how you feel about them. Pretty sweet, aint it?</div>
              </div>
          </div>  
           <div class="col-md-3 col-sm-push-1">
            <div class="descpoints">
               <div class="dphead">Mobile</div>
                <div class="divider"></div> 
                <div class="dpsubhead">With GiftMyShow cards, you can gift your friends & family movie & play tickets, concert passes, whatever it is they love for their birthdays, anniversaries or simply for no reason other than how you feel about them. Pretty sweet, aint it?</div>
              </div>
          </div>  
         
       
          
          
      </div> -->
      
   
    
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2017 <a href="#">Venue4Me</a>.</strong> All rights
    reserved.
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="plugins/jQuery/jquery.validate.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<script src="dist/js/home.js"></script>
<!--<script src="dist/js/home_validate.js"></script> -->

  
<!--<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places&key=AIzaSyAI8m8wKLvcd4NUxuyG8zY2Bp6vikCRYRw"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('place'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng();
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
                alert(mesg);
            });
        });
    </script> -->
    
        
 <script>
  // tell the embed parent frame the height of the content
  if (window.parent && window.parent.parent){
    window.parent.parent.postMessage(["resultsFrame", {
      height: document.body.getBoundingClientRect().height,
      slug: "at606jpe"
    }], "*")
  }
</script>
      
</body>
</html>