<?php

require "/api/filterAction.php";
require "/api/homeAction.php";

require "/api/loginAction.php";
require "/api/registrationAction.php";
require "/api/registrationVendorAction.php";
require "/api/vendorObjectAction.php";
require "/api/hallObjectAction.php";
require "/api/searchBookingsForVendor.php";
require "/api/vendorIndexAction.php";
require "/api/vendorBookingHistoryAction.php";
require "/api/vendorProfileAction.php";

require "/api/localityAction.php";
require "/api/cityAction.php";
require "/api/categoryAction.php";
require "/api/hallBookingAction.php";
require "/api/hallDateAction.php";
require "/api/bookAction.php";
require "/api/hallAction.php";
require "/api/hallAvailAction.php";

// Routes
$app->post('/login', \loginAction::class);
$app->post('/registration', \registrationAction::class);
$app->post('/registrationVendor', \registrationVendorAction::class);
$app->post('/vendorObject', \vendorObjectAction::class);
$app->post('/hallObject', \hallObjectAction::class);
$app->post('/searchBookingsObject', \searchBookingsForVendor::class);
$app->post('/vendorIndexObject', \vendorIndexAction::class);
$app->post('/vendorBookingHistoryObject', \vendorBookingHistoryAction::class);
$app->post('/vendorProfileObject', \vendorProfileAction::class);


$app->get('/filters', \filterAction::class);
$app->get('/localities', \localityAction::class);
$app->get('/cities', \cityAction::class);
$app->get('/types', \categoryAction::class);
$app->get('/halls', \homeAction::class);
$app->get('/hallBookings', \hallBookingAction::class);
$app->get('/hall', \hallAction::class);
$app->get('/hallAvail', \hallAvailAction::class);
$app->get('/hall_date', \hallDateAction::class);
$app->get('/book', \bookAction::class);
?>
