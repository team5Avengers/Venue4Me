<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class localityAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
        $paramValue = $request->getQueryParams();
        $city = $paramValue['city'];
        $query = 'SELECT DISTINCT(locality) from address_info where city="'.$city.'"';
        //echo $query;
        try{
            $stmt = $connection->prepare($query);
            $stmt->execute();
            $res = $stmt->get_result();
            $myArray = array();
            while($row = $res->fetch_array(MYSQL_ASSOC)) {
                $myArray[] = $row;
            }
            return $response->withJson($myArray);
            //print_r $myArray1;
          }catch(PDOException $e) {
             return json_encode($e->getMessage());
          }
        }
       //echo $whereStr;
       
}

?>