<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class cityAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
        $query = 'SELECT DISTINCT(city) from address_info';
        //echo $hall_query;
        try{
            $stmt = $connection->prepare($query);
            $stmt->execute();
            $res = $stmt->get_result();
            $myArray = array();
            while($row = $res->fetch_array(MYSQL_ASSOC)) {
                $myArray[] = $row;
            }
            return $response->withJson($myArray);
            //print_r $myArray1;
          }catch(PDOException $e) {
             return json_encode($e->getMessage());
          }
        }
       //echo $whereStr;
       
}

?>