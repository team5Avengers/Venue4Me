<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class hallAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$paramValue = $request->getQueryParams();
       $query_array = array();
	   //WE GET LOCALITY ,PACKS ,DAY, EVENT CATEGORY
       $hid="";
	   $date1="";
		foreach ($paramValue as $key => $value)
		{
            if($key=='hid'){
                $hid = $value;
            }
			
			// if($key=='dat'){
              //   $date1 = $value;
		  /*$hall_date=$value;
				 $ind_evnts=explode("-",$hall_date);
				 $hall_date="";
				 $i=0;
				 $d="";
				 $y="";
				 $m="";
				foreach ($ind_evnts as $value)
				{
					if($i==0)
					{
						$m=$value;
					}
					if($i==1)
					{
						$d=$value;
					}
					if($i==2)
					{
						$y=$value;
					}
					$i++;
				}
				$hall_date=$m."-".$d."-".$y;
				 $date1=$hall_date; */
            //}
			
		}
		//return json_encode($date1);
		
		if( $hid!="")
		{
				//$stmt = $connection->prepare($hall_query);
				//$stmt->bind_param("ss", $userName,$password);
				//$stmt->execute();
				//$res = $stmt->get_result();
				//$row = $res->fetch_assoc();
				//if($row['cnt']==1){
					$hall_query='SELECT * FROM hall a INNER JOIN address_info b ON a.vid=b.aid INNER JOIN hall_multimedia c ON a.hid=c.hid WHERE a.hid="'.$hid.'"';
				 try{
									$stmt = $connection->prepare($hall_query);
									$stmt->execute();
									$res = $stmt->get_result();
									$myArray = array();
									while($row = $res->fetch_array(MYSQL_ASSOC)) {
										$myArray[] = $row;
										//$myArray[i] = $row;//For sending entire data lets dicuss and finalize
									}
									//Sending clubbed data for both hall and address_info using hid
									return $response->withJson($myArray);
							}catch(PDOException $e) {
								return json_encode($e->getMessage());
							}
			//	}
						/*	else{
								$hall_query='SELECT * FROM hall a INNER JOIN address_info b ON a.hid=b.aid INNER JOIN hall_multimedia c ON a.hid=c.hid WHERE a.hid="'.$hid.'" ';
												 try{
									$stmt = $connection->prepare($hall_query);
									$stmt->execute();
									$res = $stmt->get_result();
									$myArray = array();
									while($row = $res->fetch_array(MYSQL_ASSOC)) {
										$myArray[] = $row;
										//$myArray[i] = $row;//For sending entire data lets dicuss and finalize
									}
									//Sending clubbed data for both hall and address_info using hid
									return $response->withJson($myArray);
							}catch(PDOException $e) {
								return json_encode($e->getMessage());
							}
							}*/
							
				
		}
		else{
			return json_encode("no input");
		}
       /* if($hid!=""){
		
          ///For sending entire data lets dicuss and finalize  //$hall_query = 'SELECT * from b.hall,a.address_info,c.hall_multimedia where a.hid=b.hid and b.hid=c.hid and b.category=' .$event.' and b.capacity='.$packs. ' and a.locality=' .$local. ';
            $hall_query='SELECT * FROM hall a INNER JOIN address_info b ON a.hid=b.aid INNER JOIN hall_multimedia c ON a.hid=c.hid INNER JOIN booking_avail d ON d.hid=a.hid WHERE a.hid="'.$hid.'" ';
			//echo $hall_query;
				 try{
									$stmt = $connection->prepare($hall_query);
									$stmt->execute();
									$res = $stmt->get_result();
									$myArray = array();
									while($row = $res->fetch_array(MYSQL_ASSOC)) {
										$myArray[] = $row;
										//$myArray[i] = $row;//For sending entire data lets dicuss and finalize
									}
									//Sending clubbed data for both hall and address_info using hid
									return $response->withJson($myArray);
							}catch(PDOException $e) {
								return json_encode($e->getMessage());
							}
        }
		*/
       
       
   }
}

?>