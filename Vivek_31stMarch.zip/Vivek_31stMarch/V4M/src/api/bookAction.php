<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class bookAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$paramValue = $request->getQueryParams();
       $query_array = array();
	   //WE GET LOCALITY ,PACKS ,DAY, EVENT CATEGORY
       $hid="";
	   $date1="";
		foreach ($paramValue as $key => $value)
		{
            if($key=='hid'){
                $hid = $value;
            }
			
			 if($key=='dat'){
                 $date1 = $value;
            }
			if($key=='slot')
			{
				$slot=$value;
			}
			
		}
		$status="booked";
	//	return json_encode($date1);
		$hall_query = 'INSERT INTO booking_avail (hid, slotid,date,status) VALUES ("'.$hid.'", "'.$slot.'","'.$date1.'", "'.$status.'")';
			try{
				$conn=new dbConnection();
                 $connection=$conn->connect_db();
				$stmt = $connection->prepare($hall_query);
				//$stmt->bind_param("ss", $userName,$password);
				$stmt->execute();
					return json_encode("success");
				}
				catch(PDOException $e) {
								return json_encode($e->getMessage());
				}
       
       
   }
}

?>