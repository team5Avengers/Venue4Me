<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class filterAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$paramValue = $request->getQueryParams();
       $query_array = array();
       $cat="";$price="";$bprice="";$feat="";$event="";$local="";$localWhere="";$whereStr="";
		foreach ($paramValue as $key => $value)
		{
            if($key=='locality'){
                $local = explode(',', $value);
                foreach ($local as $val)
                {
                    if ($val != '')
                    { $local_array[] = 'ai.locality = "'.$val.'"';}
                }
            }
			if($key=='categories'){
                $cat = explode(',', $value);
                foreach ($cat as $val)
                {
                    if ($val != '')
                    { $cat_array[] = 'h.category = "'.$val.'"';}
                }
            }
            if($key=='price'){
                $price = explode(',',$value);
                foreach ($price as $val)
                {
                    if ($val != '')
                    {
                        $priceRange = explode('-',$val);
                        $price_array[] = 'h.booking_amt BETWEEN '.$priceRange[0].' AND '.$priceRange[1];
                    
                    }
                }
            }
            if($key=='bprice'){
                $bprice = explode(',',$value);
                foreach ($bprice as $val)
                {
                    if ($val != '')
                    { 
                        $bpriceRange = explode('-',$val);
                        $bprice_array[] = 'h.booking_amt BETWEEN '.$bpriceRange[0].' AND '.$bpriceRange[1];
                    }
                }
            }
            if($key=='features'){
                $feat = explode(',',$value);
                foreach ($feat as $val)
                {
                    if ($val != '')
                    { $feat_array[] = 'h.features = "'.$val.'"';}
                }
            }
            if($key=='events'){
                $event = explode(',',$value);
                foreach ($event as $val)
                {
                    if ($val != '')
                    { $event_array[] = 'h.events LIKE "%'.$val.'%"';}
                }
            }
		}
        echo $cat;
        if($cat!="")
        {
            $whereStr = implode(' OR ', $cat_array);
        }
        if($price!="")
        {
            $whereStr = '('.$whereStr.')'.' AND '.'('.implode(' OR ', $price_array).')';
        }
        if($bprice!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $bprice_array).')';
        }
        if($feat!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $feat_array).')';
        }
        if($event!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $event_array).')';
        }
       if($local!=""){
            $localWhere = implode(' OR ',$local_array);
        }
       else
           $localWhere = "";
      /*else{
           $hall_query = 'SELECT aid,locality from address_info';
       }
            try{
				$stmt = $connection->prepare($hall_query);
				$stmt->execute();
				$res = $stmt->get_result();
                $myArray1 = array();
                while($row = $res->fetch_array(MYSQL_ASSOC)) {
                    $myArray1[] = $row;
                }
                $halls_array="";
                foreach ($myArray1 as $key=>$val)
                {
                    if ($val != '')
                    { $halls_array[] = 'h.hid = "'.$val['aid'].'"';}
                }
                //print_r($halls_array)
                if($halls_array!='')
                    $hallWhereStr = implode(' OR ', $halls_array);
                else
				    $hallWhereStr = "";
		      }catch(PDOException $e) {
			     return json_encode($e->getMessage());
		      }*/
       if($whereStr!='' && $localWhere!=''){
            $query='SELECT h.hid,h.hname,ai.locality,h.booking_amt,h.hall_shortdesc,hm.photos FROM hall h INNER JOIN hall_multimedia hm ON h.hid=hm.hid INNER JOIN address_info ai ON h.hid=ai.aid WHERE ' .$localWhere.' AND '.$whereStr;
           echo $query;
       }
       if($localWhere=='' && $whereStr!=''){
            $query='SELECT h.hid,h.hname,ai.locality,h.booking_amt,h.hall_shortdesc,hm.photos FROM hall h INNER JOIN hall_multimedia hm ON h.hid=hm.hid INNER JOIN address_info ai ON h.hid=ai.aid WHERE ' .$whereStr;
       }
       else if($localWhere!='' && $whereStr==''){
            $query='SELECT h.hid,h.hname,ai.locality,h.booking_amt,h.hall_shortdesc,hm.photos FROM hall h INNER JOIN hall_multimedia hm ON h.hid=hm.hid INNER JOIN address_info ai ON h.hid=ai.aid WHERE '.$localWhere;
       }
       else{
           $query='SELECT h.hid,h.hname,h.booking_amt,ai.locality,h.hall_shortdesc,hm.photos FROM hall h INNER JOIN hall_multimedia hm ON h.hid=hm.hid INNER JOIN address_info ai ON h.hid=ai.aid';
       }
            try{
                    $stmt = $connection->prepare($query);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    $myArray = array();
                    while($row = $res->fetch_array(MYSQL_ASSOC)) {
                        $myArray[] = $row;
                    }
                    return $response->withJson($myArray);
            }catch(PDOException $e) {
                return json_encode($e->getMessage());
            }
      /* else{
           $error = array('error_message'=>'No results found','count'=>0);
           return json_encode($error);
       }*/
       //echo $whereStr;
       
   }
}

?>