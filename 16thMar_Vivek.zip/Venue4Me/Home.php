<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Venue4ME</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min1.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<style>
 .search-bar{

position: relative;
float: left;
width:150px;
 }
 .search-bar-position{
 margin-left:28%;
 
 }
 .box-searchbar {
    position: relative;
    border-radius: 3px;
    background: rgba(242,255,255,0.43);
    border-top: 3px solid #d2d6de;
    margin-bottom: 20px;
    width: 75%;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
    padding-left: 0px;
}
.content-search-bar{
    min-height: 250px;
    padding: 15px;
    margin-right: auto;
    padding-left: 15px;
    padding-right: 15px;
}
#x{margin-top:16%;
  font-family: "Lucida Console", Monaco, monospace;
}
.divider
	{height:2px;
	width:100%;
	display:block;
	margin:9px 0;
	overflow:hidden;
	background-color:#f8c79e}
</style>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="Home.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>VENUE</b>4 ME</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="fa fa-sign-in"></span><i>&nbsp;&nbsp; Sign-in</i>
            </a>
          </li>
           <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="fa fa-sign-in"></span><i>&nbsp;&nbsp;Vendor Sign-in</i>
            </a>
          </li>
		 <li class="dropdown messages-menu" >
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="fa fa-circle-o-notch"></span><i>&nbsp;&nbsp;About Us</i>
            </a>
          </li>
           <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="fa fa-tablet"></span><i>&nbsp;&nbsp;Contact Us</i>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content-search-bar">

              <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
               <!--  <ol class="carousel-indicators">
                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                </ol> -->
                <div class="carousel-inner">
                  <div class="item active">
                    <img src="images\banner1.jpg" alt="First slide">
					<div class="carousel-caption"></div>
                  </div>
                  <div class="item">
                    <img src="images\banner03.jpg" alt="Second slide">
					<div class="carousel-caption"></div>
                  </div>
                  <div class="item">
                    <img src="images\banner2.jpg" alt="Third slide">
					<div class="carousel-caption"></div>
                  </div>
                  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <span class="fa fa-angle-left"></span>
                  </a>
                  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <span class="fa fa-angle-right"></span>
                  </a>
                </div>
                </div>
        <div style="position:relative;z-index=99; margin-top:-20%">
				<!-- <form class="col-sm-5">
                  <div class="input-group">
                    <input type="text" class="form-control">
					<input type="text" class="form-control">
					<button type="button" class="btn btn-info btn-flat">Go!</button>
                    
                  </div>
                </form> -->
				<div class="search-bar-position">
				<div class="box-searchbar box-info">
            <form class="form-horizontal" id="search_home" method="post" name="home">
              <div class="box-body">

                  <div class="search-bar">
                    <input type="text" class="form-control" id="place" name="place" placeholder="Location">
                  </div>
				  <div class="search-bar">
                    <input type="text" class="form-control" id="pacs" name="pacs" placeholder="Packs">
                  </div>
				<div class="search-bar">
                    <input type="date" class="form-control" id="date" name="date" placeholder="Date">
                  </div>
				  <div class="search-bar">
                    <select class="form-control" id="type" name="type">
					<option>Venue</option>
                    <option>Photographer</option>
                    <option>Catering</option>
                    <option>Decorator</option>
                    <option>Event Manager</option>
					</select>
                  </div>
                 <!-- <input type="submit" value="Search"> -->
				  <button type="submit" class="btn btn-info">Search</button>
              </div>
                
              <!-- /.box-footer -->
            </form>
          </div></div>
        </div>
          <!-- /.box -->
<div class="row" id="x">
<h2>&nbsp;&nbsp;Featured Halls</h2>
<div class="divider"></div>
<div class="col-lg-3 col-xs-6">
<div class="small-box bg-aqua" style="background-image: url('./images/featured2.jpg');">
<div class="inner" style="color:white;height:150px;">
<h2>Imperial Gardens</h2>
</div>
<a href="#" class="small-box-footer"style="color:white;">More info <i class="fa fa-arrow-circle-right">
</i></a></div>
</div>
<div class="col-lg-3 col-xs-6">
<div class="small-box bg-aqua" style="background-image: url('./images/featured1.jpg');">
<div class="inner" style="color:white;height:150px;">
<h2>Balaji Gardens</h2>
</div>
<a href="#" class="small-box-footer"style="color:white;">More info <i class="fa fa-arrow-circle-right">
</i></a></div>
</div>
<div class="col-lg-3 col-xs-6">
<div class="small-box bg-aqua" style="background-image: url('./images/featured3.jpg');">
<div class="inner" style="color:white;height:150px;">
<h2>Leonia Gardens</h2>

</div>
<a href="#" class="small-box-footer"style="color:white;">More info <i class="fa fa-arrow-circle-right">
</i></a></div>
</div>
<div class="col-lg-3 col-xs-6">
<div class="small-box bg-aqua" style="background-image: url('./images/featured4.jpg');">
<div class="inner" style="color:white;height:150px;">
<h2>kareena Gardens</h2>
</div>
<a href="#" class="small-box-footer"style="color:white; ">More info <i class="fa fa-arrow-circle-right">
</i></a></div>
</div>
</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2017 <a href="#">Venue4Me</a>.</strong> All rights
    reserved.
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->

</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="plugins/jQuery/jquery.validate.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<script src="dist/js/home_validate.js"></script>
<!--<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places&key=AIzaSyAI8m8wKLvcd4NUxuyG8zY2Bp6vikCRYRw"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('place'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng();
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
                alert(mesg);
            });
        });
    </script> -->
</body>
</html>
