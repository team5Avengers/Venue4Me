<?PHP	
  $route = $_GET['id'];
  $url ='http://localhost:8020/localities';
  $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $out=curl_exec($ch);
        curl_close($ch);			  

?>