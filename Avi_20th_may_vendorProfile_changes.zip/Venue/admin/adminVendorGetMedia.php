<?PHP
require_once'connection.php';
class adminVendorGetMedia{
	
	function getVendorMedia($hid){
		$conn=new dbConnection();
	$connection=$conn->connect_db();
	$query="select * from hall_multimedia where hid=?";
		$stmt = $connection->prepare($query);
				$stmt->bind_param("s", $hid);
						$stmt->execute();
			$res = $stmt->get_result();
			$row = $res->fetch_assoc();
			//$row1=array();
			//	while($row = $res->fetch_assoc()){
				//	array_push($row1, $row);
				//}		
			return json_encode($row);
	}
}




?>