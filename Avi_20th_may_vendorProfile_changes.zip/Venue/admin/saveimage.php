<?PHP
require_once'connection.php';
$conn=new dbConnection();
$connection=$conn->connect_db();
$createdBy="admin";
$date;
$hid=$_POST['hid'];
$videoPath=$_POST['videoLink'];
$photoLink=$_POST['photoLink'];
$isNewEntity=$_POST['isNewEntity'];
echo $isNewEntity;
$id;
$realPathIs="C:/xampp/htdocs/Venue/temp/images/";
$dummy=$realPathIs.$hid;
if (!file_exists($dummy)) {
    mkdir($dummy, 0777, true);
}


if (!empty($_FILES["uploadedimage"]["name"])) {

	$file_name=$_FILES["uploadedimage"]["name"];
	$temp_name=$_FILES["uploadedimage"]["tmp_name"];
	$imgtype=$_FILES["uploadedimage"]["type"];
	$ext= GetImageExtension($imgtype);
	$imagename=date("d-m-Y")."-".time().$ext;
	$target_path = $realPathIs.$hid."/".$imagename;
	$photoLink=$photoLink.";".$target_path;

if(move_uploaded_file($temp_name, $target_path)) {
	
	if($isNewEntity=="new"){
	$query="INSERT into hall_multimedia VALUES(?,?,?,?,?,?,?,?)";
	$stmt = $connection->prepare($query);
	if($stmt){
					echo($stmt->error);
				$stmt->bind_param("issssisi",$id,$hid,$photoLink,$videoPath,$createdBy,$date,$createdBy,$date);
					$stmt->execute();
					$res= "true";
					header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
	}else{
		$res= "false";
					header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
	}
 	//$query_upload="INSERT into 'hall_multimedia' VALUES('','$hid','".$target_path."','$path')";
	//mysql_query($query_upload) or die("\nerror in $query_upload == ----> ".mysql_error());  
	}else{
		
		$query="update hall_multimedia set photos='$photoLink',videos='$videoPath' where hid='$hid'";
		if($connection->query($query)){
			$res= "true"; 
				header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
		}else{
			$res= "false";
					header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
		}
	}
}else{

   echo("Error While uploading image on the server");
} 

}else{
	$query="update hall_multimedia set videos='$videoPath' where hid='$hid'";
		if($connection->query($query)){
			$res= "true"; 
				header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
		}else{
			$res= "false";
					header("Location: ../adminVendorMultiMedia.php?hid=$hid&status=$res");
		}
	
}

    function GetImageExtension($imagetype)
   	 {
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return false;
       }
     }

?>