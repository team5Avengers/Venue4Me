<?PHP
require_once'connection.php';
$conn=new dbConnection();
$connection=$conn->connect_db();
$hid=$_POST['hid'];
$vid=$_POST['vid'];
$hname=$_POST['hname'];
$category=$_POST['category'];
$booking_amt=$_POST['booking_amt'];
$pricing=$_POST['pricing'];
$seating=$_POST['seating'];
$capacity=$_POST['capacity'];
$hall_shortdesc=$_POST['hall_shortdesc'];
$hall_desc=$_POST['hall_desc'];
$features=$_POST['features'];
$menu=$_POST['menu'];
$events=$_POST['events'];
if($hid!=""&&$hid!=" "){
$query="update `hall` set `hname`='$hname',`category`='$category',`booking_amt`='$booking_amt',`pricing`='$pricing',`seating`='$seating',`capacity`='$capacity',`hall_shortdesc`='$hall_shortdesc',`hall_desc`='$hall_desc',`features`='$features',`menu`='$menu',`events`='$events' where hid='$hid'";
			if($connection->query($query)){
				 $res= "true"; 
				header("Location: ../adminViewHall.php?hid=$hid&status=$res");
				 } else {
					$res= "false";
					header("Location: ../adminViewHall.php?hid=$hid&status=$res");
				 }		
}

?>