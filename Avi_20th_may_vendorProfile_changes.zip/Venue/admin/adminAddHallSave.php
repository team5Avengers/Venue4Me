<?PHP
require_once'connection.php';
$conn=new dbConnection();
$connection=$conn->connect_db();
$vid=$_POST['vid'];
$hid=$_POST['hid'];
$hname=$_POST['hname'];
$categary=$_POST['categary'];
$bookingAmount=$_POST['bookingAmount'];
$pricing=$_POST['pricing'];
$seating=$_POST['seating'];
$capacity=$_POST['capacity'];
$hsDesc=$_POST['hsDesc'];
$hDesc=$_POST['hDesc'];
$features=$_POST['features'];
$menu=$_POST['menu'];
$events=$_POST['events'];
$id;
$createdBy="admin";
$date;
echo "hai ".$vid."hello";
if($vid!=""&&$vid!=" "){
	echo "hello\n";
	$query="insert into hall values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	echo "hello1\n";
				$stmt = $connection->prepare($query);
			if($stmt){
				$stmt->bind_param("issssssssssssssisi",$id,$hid,$hname,$categary,$bookingAmount,$pricing,$hsDesc,$hDesc,$features,$capacity,$menu,$seating,$events,$vid,$createdBy,$date,$createdBy,$date);
					$stmt->execute();
					echo("Error is %s\n".$stmt->error);
					 $stmt->close();
					 $res= "true";
				    header("Location: ../adminViewHall.php?hid=$hid&status=$res");
				 } else {
					 echo("Error is %s".$stmt->error);
					$res= "false";
					header("Location: ../adminViewHall.php?hid=$hid&status=$res");
				 }		
}


?>