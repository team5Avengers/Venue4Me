<?PHP
require_once'connection.php';
class adminVendorInfoGet{
function getVendorInfo($vid){
	$conn=new dbConnection();
	$connection=$conn->connect_db();
$query="select * from vendor v,address_info ai where v.vid=ai.aid and v.vid=?";
		$stmt = $connection->prepare($query);
				$stmt->bind_param("s", $vid);
						$stmt->execute();
			$res = $stmt->get_result();
			//$row = $res->fetch_assoc();
			$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				}		
			return json_encode($row1);
}

function getVendorHallInfo($vid){
	$conn=new dbConnection();
	$connection=$conn->connect_db();
$query="select * from hall where vid=?";
		$stmt = $connection->prepare($query);
				$stmt->bind_param("s", $vid);
						$stmt->execute();
			$res = $stmt->get_result();
			//$row = $res->fetch_assoc();
			$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				}		
			return json_encode($row1);
	
}
}
?>