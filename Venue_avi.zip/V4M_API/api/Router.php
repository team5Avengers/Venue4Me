<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require '../vendor/autoload.php';
require "./src/loginAction.php";
require "./src/registrationAction.php";
require "./src/registrationVendorAction.php";
require "./src/vendorObjectAction.php";

$app = new \Slim\App;
$app->post('/login', \loginAction::class);
$app->post('/registration', \registrationAction::class);
$app->post('/registrationVendor', \registrationVendorAction::class);
$app->post('/vendorObject', \vendorObjectAction::class);
$app->run();