<?PHP
require_once'./restHandlers/listHallsRestHandler.php';
$li = new listHallsRestHandler();
$det_array = $li->getInfo();
$halls = $li->getHalls();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Venue4ME</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link href="./plugins/datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="plugins/select2/select2.min.css">
  <link rel="stylesheet" href="plugins/bootstrap-slider/slider.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
	<link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="./plugins/multiselect/css/bootstrap-multiselect.css" type="text/css" />
	

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<!-- ADD THE CLASS fixed TO GET A FIXED HEADER AND SIDEBAR LAYOUT -->
<!-- the fixed layout is not compatible with sidebar-mini -->
<body class="hold-transition skin-green-light fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="Home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>V</b>4Me</span>
      <!-- logo for regular state and mobile devices -->
     <span class="logo-lg"><img src="images/v4me.png" style="height: 45px; widht: 150px" /></span>  
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Notifications: style can be found in dropdown.less -->
         
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Alexander Pierce</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  Alexander Pierce - Web Developer
                  
                </p>
              </li>
                            <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
                    <a href="#"></a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Favourites</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#"></a>
                  </div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        <!--  <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li> -->
        </ul>
      </div>
    </nav>
  </header>

  <!-- =============================================== -->
  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
				<li class="treeview active">
				  <a href="#">
					<i class="fa fa-location-arrow"></i>
					<span>Refine your search</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-left pull-right"></i>
					</span>
					<!--<span class="pull-right-container">
					  <span class="label label-primary pull-right">4</span>
					</span>-->
				  </a>
				  <ul class="treeview-menu">
                    <form name="modify" id="modify">
					<li>
						<div class="form-group">
						  <label>Location:</label>
						  <select class="form-control" id="city" name="city" style="width: 95%;">
								<option selected ><?PHP echo $det_array[0]; ?></option>
								<!--<option>Hyderabad</option>
								<option>Secundrabad</option>
								<option>Warangal</option> -->                 
						  </select>
						</div>
					</li>
					  
					<li>
						<div class="form-group">
						  <label>Area:</label>
						  <select class="form-control" id="area" name="area" style="width: 95%;">
								<option selected ><?PHP echo $det_array[1]; ?></option>         
						 </select>
						</div>
					</li>
					  
					<li>
						<div class="form-group">
						  <label>Looking For:</label>
						  <select class="form-control" id="city" style="width: 95%;" disabled>
							<option value="<?PHP echo $det_array[2]; ?>" selected><?PHP echo $det_array[2]; ?></option>    
							<!--<option>Venue</option>
							<option>Photographer</option>
							<option>Catering</option>
							<option>Decorator</option>
							<option>Event Manager</option>       -->            
						  </select>
						</div>
					</li>
					  
					<li>
						<div class="form-group">
						  <label>Category:</label>
						  <select class="form-control" id="cat" name="category" style="width: 95%;">
								<option selected ><?PHP echo $det_array[3]; ?></option>
						  </select>
						</div>
					</li>
						
					<li>
						<div class="form-group">
						  <label>Guests:</label>
						  <select class="form-control" id="pacs" name="pacs" style="width: 95%;">
								<option selected ><?PHP echo $det_array[4]; ?></option>
							<!--	<option>1-300</option>
								<option>301-500</option>
								<option>500-1000</option>
								<option>>1000</option>     -->             
						  </select>
						</div>
					</li>
				    <button type="submit" style="center" class="btn btn-info" id="sch">Search</button>
                    <button type="button" style="center" class="btn btn-info" id="mod">Modify</button>
                  </form>
				  </ul>
				</li>
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-location-arrow"></i>
                    <span>Event Time</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                    <!--<span class="pull-right-container">
                      <span class="label label-primary pull-right">4</span>
                    </span>-->
                  </a>
                  <ul class="treeview-menu">
                  <form name="time" id="time" >
                      <li>
                        <div class="form-group">
                          <label>From Date:</label>
                            <div class="input-group date form_datetime" data-link-field="dtp_input1" style="width: 95%;">
                                <input class="form-control" id="ftime" size="48" type="text" readonly>
                                <span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="form-group">
                          <label>To Date:</label>
                         <div class="input-group date form_datetime" data-link-field="dtp_input1" style="width: 95%;">
                            <input class="form-control" id="ttime" size="48" type="text" readonly>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                        </div>
                        </div>
                    </li>
                    <button type="submit" style="center" class="btn btn-info" id="sch">Search</button>
                  </form>
                  </ul>
                </li>
                 
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-location-arrow"></i>
                    <span>Features</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                    <!--<span class="pull-right-container">
                      <span class="label label-primary pull-right">4</span>
                    </span>-->
                  </a>
                  <ul class="treeview-menu">

                      <li>
                        <div class="form-group">
                          <label>Hall Type</label>
                          <select class="form-control" id="city" style="width: 95%;">
                                <option>AC</option>
                                <option>Non-AC</option>    
                          </select>
                        </div>
                    </li>
                    
                    <li>
                        <div class="form-group">
                            <label>Food Type</label>
                                <br>
                            <select id="chkveg1" class="form-control col-md-16"  multiple="multiple">
                                <option value="cheese">Veg</option>
                                <option value="tomatoes">Non-Veg</option>
                            </select>
                        </div>
                    </li>  
                      
                    <li>
                        <div class="form-group">
                            <label>Events</label>
                                <br>
                            <select class="form-control select2" multiple="multiple" data-placeholder="Select Events" style="width: 95%;">
                              <option>Birthday Party</option>
                              <option>Weddings</option>
                              <option>Meeting</option>
                              <option>Get Together</option>
                              <option>Cocktail party</option>
                            </select>
                        </div>
                    </li>  
                    
                  </ul>
                </li>
        </ul>
	</section>
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List of Venues found.
        <small style="color: white"><?PHP echo count($halls); ?> venues found.</small>
      </h1>
        <?PHP
        if(count($halls)==0){
    ?>
      <div class="callout callout-info">
                <h4>Please Modify your search.</h4>
     </div>
    <?PHP
        }
            ?>
      <!--<ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Layout</a></li>
        <li class="active">Fixed</li>
      </ol>-->
    </section>
    

    <!-- Main content -->
      <section class="content">
        <?PHP
            foreach($halls as $hall){
        ?>
          <!-- /.box -->
        <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title"><?PHP echo $hall->hname.', '.$hall->locality; ?></h3>
            </div>
            <div class="box-body no-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-xs-5">
							<div class="small-box bg-aqua" style="background-image: url('<?PHP echo str_replace("\\","/",$hall->photos); ?>');">
								<div class="inner" style="color:white;height:150px;">
									<h5><a href=""><i class="fa fa-heart symbolheart" aria-hidden="true"></i></a>Add Favourite</h5>
								</div>
                            </div>
						</div>
                        <div class="col-md-5" style="margin-top:2%;">
                            <table>
                                <tr>
                                    <td>Capacity: <?PHP echo $hall->capacity; ?></td>
                                    <td>Price:  <?PHP echo $hall->booking_amt; ?></td>
                                </tr>
                                <tr>
                                    <td>Type : A/C Hall</td>
                                    <td>Outside Not Allowed : <?PHP echo $hall->notAllowed; ?></td>
                                </tr>
                               <tr>
                                    <td>No of Enquiries : 10</td>
                               </tr>
                            </table>
                        </div>
                        
                        <div class="col-md-3 col-sm-push-1" style="margin-top:10%;">
                            <?PHP  
                                if(isset($_SESSION['un']))
                                {	
                                    $details=$_SESSION['un'];
                                    //$det_array = explode(";",$details);
                            ?>
							<a href="venue.php?hid=<?PHP echo $hall->hid; ?>"><button type="button" onclick="" class="btn bg-orange">Check Availability</button></a>
                            <?PHP   
                                }
                                else{
                                    ?>
                            <a href="login.php"><button type="button" onclick="" class="btn bg-orange">Check Availability</button></a>
                            <?PHP  } ?>
						</div>
                    </div>
                </div>
            </div>
        </div>
        <?PHP }
        ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
</div>
  <footer class="main-footer">
    <div class="container" align="center">
      <strong>Copyright &copy; 2017 <a href="#">Venue4Me</a>.</strong> All rights
      reserved.
    </div>
  </footer>

<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="plugins/jQuery/jquery.validate.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="dist/js/halls.js"></script>
<script src="plugins/select2/select2.full.min.js"></script>
<script src="plugins/bootstrap-slider/bootstrap-slider.js"></script>
<script src="plugins/multiselect/js/bootstrap-multiselect.js"></script>
<script src="plugins/datetimepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        language:  'en',
        weekStart: 1,
        pickTime: false,
        todayBtn:  1,
		todayHighlight: 1,
		startView: 2,
        startDate: new Date(),
        minView :1,
		forceParse: 0,
        showMeridian: 1,
        format: 'dd-mm-yyyy hh:00',
		autoclose: true
     
    });
      $('.form_datetime').datetimepicker({
    minDate: new Date()
     }).on("changeDate", function(selectedDate) {
      var minDate = new Date(selectedDate.date.valueOf());
          //alert(minDate);
            $('.to_datetime').datetimepicker('setStartDate', minDate);

     });
    
    $('.to_datetime').datetimepicker({
        language:  'en',
        weekStart: 1,
        pickTime: false,
        todayBtn:  1,
		todayHighlight: 1,
		startView: 2,
        minView :1,
		forceParse: 0,
        showMeridian: 1,
        format: 'dd-mm-yyyy hh:00',
		autoclose: true
     
    }); 
     $(".to_datetime").datetimepicker()
        .on('changeDate', function (selected) {
            var maxDate = new Date(selected.date.valueOf());
            $('.form_datetime').datetimepicker('setEndDate', maxDate);
        });
</script>
<script>
  $(function () {
    /* BOOTSTRAP SLIDER */
    $('.slider').slider();
	$(".select2").select2();
    /*$('#dt').datepicker({
      autoclose: true,
      minDate: 0 
    }); */
  });
</script>

</body>
</html>
