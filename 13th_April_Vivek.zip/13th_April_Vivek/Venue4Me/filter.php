<?PHP	
//$userName="Aviansh";
  //$locality = $_GET['locality'];
  $route = $_GET['id'];
    $cat = $_GET['cat'];
    $feat = $_GET['feat'];
    $pr = $_GET['pr'];
    $prp = $_GET['prp'];
    $loc = $_GET['loc'];
    $event = $_GET['event'];
    $par = "";
/*
    if($loc!="" && $loc!='null'){
        $par = $par."locality=".$loc."&";
    }
    if($cat!=""){
        $par = $par."categories=".$cat."&";
    }
    if($pr!=""){
        $par = $par."price=".$pr."&";
    }
    if($prp!=""){
        $par = $par."bprice=".$prp."&";
    }
    if($feat!=""){
        $par = $par."fetaures=".$feat;
    }*/
    $par = $par."locality=".$loc."&";
    $par = $par."categories=".$cat."&";
    $par = $par."price=".$pr."&";
    $par = $par."bprice=".$prp."&";
    $par = $par."features=".$feat."&";
    $par = $par."events=".$event;
    $url ='http://localhost:8020/filters?'.$par;
  $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $out=curl_exec($ch);
        $details = json_decode($out);
        $res = "";
        foreach($details as $hall){ 
             $res = $res."\n".' <div class="box box-default">
                  <div class="box-header with-border">
                    <h3 class="box-title">'.$hall->hname.', '.$hall->locality.'</h3>
                  </div>
                  <div class="box-body no-padding">

                    <table class="table table-condensed no-border">
                        <tr>
                            <td rowspan="3"> <img src="'.$hall->photos.'" alt="Image1" style="height: 100px;width: 150px" /></td>
                            <td align="left">'.$hall->hall_shortdesc.'</td>
                            <td><div class="box-tools pull-right">
                                    <h4>Price: Rs.'.$hall->booking_amt.'</h4>
                            </div></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><div class="box-tools pull-right">
                                    <a href="venue.html?id='.$hall->hid.'"><button type="button" class="btn bg-orange" title="Collapse">Check Availability</button></a>
                                </div></td>
                        </tr>
                   </table>
                  </div>
              </div>';
    }
    echo $res;
    curl_close($ch);			  
?>