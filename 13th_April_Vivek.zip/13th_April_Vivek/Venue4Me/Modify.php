<?PHP	
  $value =  (json_decode(stripslashes($_REQUEST['values']), true));
   //print_r($value);
    $city = $value[0]['value'];
    $locality = $value[1]['value'];
    $type = $value[4]['value'];
    $cat = $value[2]['value'];
    $pacs = $value[3]['value'];
    $info = $city.";".$locality.";".$type.";".$cat.";".$pacs;
//    $url = "http://localhost:8020/halls";
    if($type=="Venue"){
        $url = 'http://localhost:8020/halls?locality='.urlencode($locality).'&packs='.$pacs.'&category='.urlencode($cat);
        //echo $url;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $out=curl_exec($ch);
        $details = json_decode($out);
        $res = "";
        if($details==""){
            $res = $res."\n".'<h1>
        List of Venues.
        <small>'.'0 venues found.</small>
      </h1>'."\n".'
      <div class="callout callout-info">
                <h4>Please Modify your search.</h4>
     </div>';
        }
        else{
            session_start();
            $_SESSION['info'] = $info;
            $res = $res.'<section class="content-header">
                          <h1>
                            List of Venues found.
                            <small>'.count($details).' venues found.</small>
                          </h1>';
            if(count($details)==0){
                $res = $res.'<div class="callout callout-info">
                                <h4>Please Modify your search.</h4>
                            </div></section>';
            }
            else{
                $res = $res.'</section>';
            }
                        
            $res = $res.'<section class="content">';
            foreach($details as $hall){ 
                
                 $res = $res."\n".'<div class="box box-default">
                      <div class="box-header with-border">
                        <h3 class="box-title">'.$hall->hname.', '.$hall->locality.'</h3>
                      </div>
                      <div class="box-body no-padding">
                        <div class="container">
                            <div class="row">
				                <div class="col-lg-3 col-xs-5">
                                    <div class="small-box bg-aqua" style="background-image: url('.str_replace("\\","/",$hall->photos).')">
                                    <div class="inner" style="color:white;height:150px;">
									   <h5><a href=""><i class="fa fa-heart" aria-hidden="true"></i></a>Add Favourite</h5>
								    </div>
                                </div>
                            </div>
			             <div lass="col-md-2 " style="margin-top:2%;">
                            <table>
                                <tr>
                                    <td>
                                    Capacity : '.$hall->capacity.'
                                    </td>

                                    <td>
                                    Price:  '.$hall->booking_amt.'
                                    </td>
                                </tr>
                                          <tr>
                                    <td>
                                    Type: A/C Hall
                                    </td>
                                    <td>
                                    Outside Not Allowed: '.$hall->notAllowed.'
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                     No of Enquiries : 10        
                                    </td>
                                </tr>
                            </table>
                        </div>
		              <div class="col-md-3 col-sm-push-6" style="margin-top:4%;">
							<a href="venue.php?hid='.$hall->hid.'"><button type="button" class="btn bg-orange">Check Availability</button></a>
				      </div>
                    </div>
                </div>
            </div>
        </div>';
        }
        $res = $res.'</section>';
    }
    echo $res;
        //echo json_decode($out);
		curl_close($ch);
        //header("Location: List_halls.php");
        exit();
    }			  
?>