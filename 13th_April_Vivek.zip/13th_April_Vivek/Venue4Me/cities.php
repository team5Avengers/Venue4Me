<?PHP	
  $route = $_GET['id'];
  if($route=='city')
  {
    //$city = $_GET['city'];
    $url ='http://localhost:8020/cities';
  }
  else if($route=='area')
  {
    $city = $_GET['city'];
    $url ='http://localhost:8020/localities?city='.$city;
  }
  else if($route=='type')
  {
    $cat = $_GET['cat'];
    $url ='http://localhost:8020/types?cat='.$cat;
  }
  $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $out=curl_exec($ch);
        curl_close($ch);			  

?>