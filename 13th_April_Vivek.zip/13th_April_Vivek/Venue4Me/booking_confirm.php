<?PHP
 //$value =  (json_decode(stripslashes($_REQUEST['values']), true));
   // print_r($value);

	session_start();
 	  $halls="";
	  $date1="";
      if(isset($_SESSION['hal']))
			{	
				$halls=$_SESSION['hal'];
            }
			 if(isset($_SESSION['date1']))
			{	
				$date1=$_SESSION['date1'];
            }
			$hall_name="";$slot1="Slot - 1";$slot2="Slot - 2"; $slot3="Slot - 3"; $slot4="Slot - 4";$slot1_time="12 AM - 6 AM";$slot2_time="6 AM - 12 PM";$slot3_time="12 PM - 6 PM";$slot4_time="6 PM - 12 AM";
			$slot1_status="Available";$slot2_status="Available";$slot3_status="Available";$slot4_status="Available";
			$hall_amt="";$hall_desc="";$hall_events="";
			$hall_id="";
			$hall_loc="";
		if($halls!="")
        foreach($halls as $hall)
		{
			$hall_id=$hall->hid;
			$hall_name=$hall->hname;
			$hall_events=$hall->events;
			$hall_amt=$hall->booking_amt;
			$hall_loc=$hall->locality;
			$hall_desc=$hall->hall_shortdesc;
			try{
				if(isset($hall->slotid))
				{
			if($hall->slotid=="s1")
			{
				$slot1_status="Booked";
				
			}
			if($hall->slotid=="s2")
			{
				$slot2_status="Booked";
				
			}
			if($hall->slotid=="s3")
			{
				$slot3_status="Booked";
				
			}
			if($hall->slotid=="s4")
			{
				$slot4_status="Booked";
				
			}
			}
			}
			catch(Exception $e) {
								
							}
			
		}
    //$url = "http://localhost:8020/hall";
  
        $url = "http://localhost:8020/book?hid=$hall_id&dat=$date1&slot=s2";
        $ch = curl_init($url);		
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$out=curl_exec($ch);
        echo "output".$out;
       // session_start();
        //$_SESSION['hal']=json_decode($out);
        //echo json_decode($out);
		curl_close($ch);
		echo '<script language="javascript">';
		echo 'alert( "Your hall booked successfully");';
		echo '</script>';
        if(isset($_SESSION['hal']))
        {
            $_SESSION['hal']="";
            
        }
       if(isset($_SESSION['date1']))
			{	
              $_SESSION['date1']="";
            }
        //header("Location: Home.php");
        exit();
   
?>