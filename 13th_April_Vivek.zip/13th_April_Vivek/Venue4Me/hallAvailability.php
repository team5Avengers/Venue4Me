<?PHP	
  $hid = $_GET['hid'];
  $dat = $_GET['dat'];
  $url ='http://localhost:8020/hallAvail?hid='.$hid.'&dat='.$dat;
  $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $out=curl_exec($ch);
        $avail = json_decode($out);
        $slot = array();
        $slot['date'] = $dat;
        $slot['S1']= "available";
        $slot['S2']= "available";
        $slot['S3']= "available";
        $slot['S4']= "available";
        foreach($avail as $av){
            if(strpos($av->slotid, ';') !== false){
                $slots = explode(";",$av->slotid);
                foreach($slots as $sl){
                        $slot[$sl] = $av->status;
                }
            }
            else
                $slot[$av->slotid] = $av->status;
             
        }
        $s1 = "";
        $s2 = "";
        $s3 = "";
        $s4 = "";
        $def = '<span class="badge bg-green">Available</span>';
        foreach($slot as $key => $value){
            if($key == "S1"){
                if($value=="available")
                   $s1 = '<span class="badge bg-green">Available</span>';
                else if($value=="booked")
                    $s1 = '<span class="badge bg-orange">Available</span>';
                else if($value=="blocked")
                   $s1 = '<span class="badge bg-red">Available</span>';
            }
            else if($key == "S2"){
                if($value=="available")
                   $s2 = '<span class="badge bg-green">Available</span>';
                else if($value=="booked")
                    $s2 = '<span class="badge bg-orange">Available</span>';
                else if($value=="blocked")
                   $s2 = '<span class="badge bg-red">Available</span>';
            }
            else if($key == "S3"){
                if($value=="available")
                   $s3 = '<span class="badge bg-green">Available</span>';
                else if($value=="booked")
                    $s3 = '<span class="badge bg-orange">Available</span>';
                else if($value=="blocked")
                   $s3= '<span class="badge bg-red">Available</span>';
            }
            else if($key == "S4"){
                if($value=="available")
                   $s4 = '<span class="badge bg-green">Available</span>';
                else if($value=="booked")
                    $s4 = '<span class="badge bg-orange">Available</span>';
                else if($value=="blocked")
                   $s4 = '<span class="badge bg-red">Available</span>';
            }
        }
        $res = "";
        if(count($avail)>0){
            $res = '<table class="table table-condensed">
                        <tr>
                          <th>Slot</th>
                          <th>Time</th>
                          <th>Status</th>
                          </tr>
                        <tr>
                          <td> Slot-1</td>
                          <td>
                             12AM - 6AM
                          </td>
                          <td>'.$s1.'</td>
                        </tr>
                        <tr>
                          <td> Slot-2</td>
                          <td>
                            6AM - 12PM
                          </td>
                          <td>'.$s2.'</td>
                        </tr>
                        <tr>
                          <td> Slot-3</td>
                          <td>
                             12PM - 6PM
                          </td>
                          <td>'.$s3.'</td>
                        </tr>
                        <tr>
                          <td> Slot-4</td>
                          <td>
                             6PM - 12AM
                          </td>
                          <td>'.$s4.'</td>
                        </tr>
                      </table>';
        }
        else{
            $res = '<table class="table table-condensed">
                        <tr>
                          <th>Slot</th>
                          <th>Time</th>
                          <th>Status</th>
                          </tr>
                        <tr>
                          <td> Slot-1</td>
                          <td>
                             12AM - 6AM
                          </td>
                          <td>'.$def.'</td>
                        </tr>
                        <tr>
                          <td> Slot-2</td>
                          <td>
                            6AM - 12PM
                          </td>
                          <td>'.$def.'</td>
                        </tr>
                        <tr>
                          <td> Slot-3</td>
                          <td>
                             12PM - 6PM
                          </td>
                          <td>'.$def.'</td>
                        </tr>
                        <tr>
                          <td> Slot-4</td>
                          <td>
                             6PM - 12AM
                          </td>
                          <td>'.$def.'</td>
                        </tr>
                      </table>';
        }
            
        echo $res;
		curl_close($ch);
        exit();			  
?>