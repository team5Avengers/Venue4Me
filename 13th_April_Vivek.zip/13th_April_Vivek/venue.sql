-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.16 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for venue4me
CREATE DATABASE IF NOT EXISTS `venue4me` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `venue4me`;


-- Dumping structure for table venue4me.addon
CREATE TABLE IF NOT EXISTS `addon` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `description` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `aid` (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.addon: ~0 rows (approximately)
/*!40000 ALTER TABLE `addon` DISABLE KEYS */;
/*!40000 ALTER TABLE `addon` ENABLE KEYS */;


-- Dumping structure for table venue4me.address_info
CREATE TABLE IF NOT EXISTS `address_info` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` varchar(10) NOT NULL,
  `street1` varchar(300) NOT NULL,
  `street2` varchar(150) NOT NULL,
  `landmark` varchar(50) NOT NULL,
  `locality` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `postalcode` varchar(6) NOT NULL,
  `longitude` float NOT NULL DEFAULT '0',
  `latitude` float NOT NULL DEFAULT '0',
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `aid` (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.address_info: ~22 rows (approximately)
/*!40000 ALTER TABLE `address_info` DISABLE KEYS */;
INSERT INTO `address_info` (`Id`, `aid`, `street1`, `street2`, `landmark`, `locality`, `city`, `state`, `country`, `postalcode`, `longitude`, `latitude`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'v1', 'U.S. Consulate Lane', 'Chiraan Fort Club', 'NA', 'Begumpet', 'Secunderabad', 'Telangana', 'India', '500003', 17.4394, 78.4749, '', '2017-03-28 20:54:14', '', '2017-03-28 20:54:14'),
	(2, 'v2', 'Sagar Road', 'Garden Street', '', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500079', 17.3473, 78.517, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(3, 'v3', 'Sagar Road', 'Garden Street', '', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500079', 17.3481, 78.5187, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(4, 'v4', '17-1-382/K/6/6', 'Garden Street', 'Champapet Road', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500059', 17.349, 78.5191, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(5, 'v5', 'Nagarjuna Colony', 'New Santhosh Nagar', 'Champapet Road', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500079', 17.3447, 78.5274, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(6, 'v6', '17-1-382/10', 'KNR Complex', 'RTC Colony', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500060', 17.3457, 78.522, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(7, 'v7', '26th Mile Stone', 'Srisailam Highway', 'Near RGI Airport', 'Maheshwaram', 'Hyderabad', 'Telangana', 'India', '501359', 17.1388, 78.4723, '', '2017-03-25 21:40:27', '', '2017-03-25 21:40:27'),
	(8, 'v8', 'Saroor Nagar Main Road', 'Backside of Srisis Company', 'Opp: Dargah', 'L.B.Nagar', 'Hyderabad', 'Telangana', 'India', '500074', 17.3488, 78.5441, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(9, 'v9', 'Nirmala Nagar Colony', 'Karmanghat Road', '', 'Karmanghat', 'Hyderabad', 'Telangana', 'India', '500074', 17.3446, 78.5335, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(10, 'v10', 'Bhairamalguda', 'Sagar Road', '', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500074', 17.3421, 78.5432, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(11, 'v11', '9-4-165', '', '', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500035', 17.3432, 78.5136, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(12, 'v12', 'Garden Street', 'Sagar Road', '', 'Champapet', 'Hyderabad', 'Telangana', 'India', '500079', 17.3475, 78.5166, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(13, 'v13', 'Hall No.1', 'Teachers Colony', 'Opp: Delta Hospital', 'Hasthinapuram', 'Hyderabad', 'Telangana', 'India', '500074', 17.3245, 78.5573, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(14, 'v14', '8-5-146', 'Mailardevpally', 'Durga Nagar', 'Rajendra Nagar', 'Hyderabad', 'Telangana', 'India', '500005', 17.3137, 78.4482, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(15, 'v15', 'Hotel Swagath Grand', 'Alkapuri X Road', '', 'Nagole', 'Hyderabad', 'Telangana', 'India', '500068', 17.3635, 78.5577, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(16, 'v16', 'Medipally', 'Canara Nagar', '', 'Peerzadiguda', 'Hyderabad', 'Telangana', 'India', '500098', 17.4024, 78.5999, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(17, 'v17', 'Survey No.4, Narne Road', 'Film Nagar', 'Adjacent to Whisper Valley', 'Jubilee Hills', 'Hyderabad', 'Telangana', 'India', '500008', 17.4147, 78.395, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(18, 'v18', 'Survey No.177/1', 'Aziz Nagar Village', 'Moinabad Mandal', 'RR Dist', 'Hyderabad', 'Telangana', 'India', '500075', 17.3527, 78.3375, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(19, 'v19', 'Sagar Mahal Complex', 'Gandipet Village', 'Near Osman Sagar Lake', 'RR Dist', 'Hyderabad', 'Telangana', 'India', '500075', 17.3895, 78.3162, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(20, 'v20', 'F2, Shahgul\'s Nest', 'Vijay Nagar Colony', 'Lane Beside NMDC', 'Masab Tank', 'Hyderabad', 'Telangana', 'India', '500057', 17.3947, 78.4515, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(21, 'v21', 'Aziz Nagar Village', 'Behind Himayat Sagar Lake', 'Near Appa Junction', 'Mrugavani National Park', 'Hyderabad', 'Telangana', 'India', '500075', 17.3237, 78.3388, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04'),
	(22, 'v22', 'Sy. No. 13P, Chilukuri Balaji Temple Road', 'Aziz Nagar Village', 'Moinabad Mandal', 'RR Dist', 'Hyderabad', 'Telangana', 'India', '500075', 17.3447, 78.3315, '', '2017-03-25 20:47:04', '', '2017-03-25 20:47:04');
/*!40000 ALTER TABLE `address_info` ENABLE KEYS */;


-- Dumping structure for table venue4me.booking_avail
CREATE TABLE IF NOT EXISTS `booking_avail` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` varchar(10) NOT NULL,
  `slotid` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.booking_avail: ~7 rows (approximately)
/*!40000 ALTER TABLE `booking_avail` DISABLE KEYS */;
INSERT INTO `booking_avail` (`Id`, `hid`, `slotid`, `date`, `status`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'h6', 'S1;S2;S3', '2017-04-12', 'booked', '', '2017-03-22 00:00:03', '', '2017-04-13 20:51:42'),
	(2, 'h6', 'S1;S2;S3', '2017-04-13', 'blocked', '', '2017-03-22 00:00:03', '', '2017-04-13 20:51:45'),
	(4, 'h7', 'S2;S3;S4', '0000-00-00', 'booked', '', '2017-03-22 00:00:03', '', '2017-03-22 00:11:26'),
	(5, 'h8', 'S1;S2', '2017-04-14', 'booked', '', '2017-03-22 00:00:03', '', '2017-04-05 23:53:28'),
	(6, 'h9', 'S2;S3', '0000-00-00', '', '', '2017-03-22 00:00:03', '', '2017-03-22 00:00:03'),
	(7, 'h10', 'S3;S4', '0000-00-00', '', '', '2017-03-22 00:00:03', '', '2017-03-22 00:00:03'),
	(8, 'h8', 'S3', '2017-04-20', 'blocked', '', '2017-03-28 13:06:06', '', '2017-04-05 23:53:36');
/*!40000 ALTER TABLE `booking_avail` ENABLE KEYS */;


-- Dumping structure for table venue4me.booking_transaction
CREATE TABLE IF NOT EXISTS `booking_transaction` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(10) NOT NULL,
  `booking_id` varchar(10) NOT NULL,
  `transactionId` varchar(50) NOT NULL,
  `transaction_type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  UNIQUE KEY `transactionId` (`transactionId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.booking_transaction: ~0 rows (approximately)
/*!40000 ALTER TABLE `booking_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_transaction` ENABLE KEYS */;


-- Dumping structure for table venue4me.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `customerid` (`customerid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.customer: ~2 rows (approximately)
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`Id`, `customerid`, `name`, `email`, `contact`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'C1', 'Vivek', 'v@g.com', '9848022338', 'self', '2017-03-16 11:36:38', 'self', '2017-04-09 14:41:54'),
	(2, 'C2', 'k', 'k@v.com', '9848022338', 'self', '2017-03-18 08:37:04', 'self', '2017-04-09 14:42:07');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


-- Dumping structure for table venue4me.hall
CREATE TABLE IF NOT EXISTS `hall` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` varchar(15) NOT NULL DEFAULT '0',
  `hname` varchar(100) NOT NULL DEFAULT '0',
  `category` varchar(15) NOT NULL DEFAULT '0',
  `booking_amt` float NOT NULL DEFAULT '0',
  `pricing` float NOT NULL DEFAULT '0',
  `hall_shortdesc` varchar(100) NOT NULL DEFAULT '0',
  `hall_desc` varchar(500) NOT NULL DEFAULT '0',
  `features` varchar(500) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `menu` varchar(100) NOT NULL DEFAULT '0',
  `events` varchar(300) NOT NULL DEFAULT '0',
  `notAllowed` varchar(300) NOT NULL DEFAULT '0',
  `parking_capacity` varchar(300) NOT NULL DEFAULT '0',
  `vid` varchar(10) NOT NULL DEFAULT '0',
  `created_by` varchar(20) NOT NULL DEFAULT '0',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL DEFAULT '0',
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `hid` (`hid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.hall: ~28 rows (approximately)
/*!40000 ALTER TABLE `hall` DISABLE KEYS */;
INSERT INTO `hall` (`Id`, `hid`, `hname`, `category`, `booking_amt`, `pricing`, `hall_shortdesc`, `hall_desc`, `features`, `capacity`, `menu`, `events`, `notAllowed`, `parking_capacity`, `vid`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'h1', 'Lotus1', 'Banquet', 10000, 1025, 'abc', 'An environmentally responsible hotel with various Eco initiatives, Manasarovar-The Fern, in Hyderabad is the most centrally located next to U.S.Consulate, Begumpet, Secunderabad, and situated in close proximity at a distance of 4km and 06 km from the Railway station and 38 Km from international and domestic airports. This hotel comprises of 102 rooms and suites with all modern facilities and ample space. With easy access to Secunderabad main transit options, and within a 06 km radius of the Amee', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;2524 Sq.ft;Car Parking-200;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Valet Parking;Backup Power;Sound System;Stage', 1200, 'image', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell', 'Drinking;Caterer', '400', 'v1', '0', '2017-03-26 14:18:31', '0', '2017-03-31 10:37:55'),
	(2, 'h2', 'Lotus 2', 'Banquet', 10000, 1025, 'abc', 'An environmentally responsible hotel with various Eco initiatives, Manasarovar-The Fern, in Hyderabad is the most centrally located next to U.S.Consulate, Begumpet, Secunderabad, and situated in close proximity at a distance of 4km and 06 km from the Railway station and 38 Km from international and domestic airports. This hotel comprises of 102 rooms and suites with all modern facilities and ample space. With easy access to Secunderabad main transit options, and within a 06 km radius of the Amee', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;2524 Sq.ft;Car Parking-200;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Valet Parking;Backup Power;Sound System;Stage', 400, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;FresherFarewell ', 'Drinking;Caterer', '400', 'v1', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:44:23'),
	(3, 'h3', 'Lotus 3', 'Banquet', 10000, 1025, 'abc', 'An environmentally responsible hotel with various Eco initiatives, Manasarovar-The Fern, in Hyderabad is the most centrally located next to U.S.Consulate, Begumpet, Secunderabad, and situated in close proximity at a distance of 4km and 06 km from the Railway station and 38 Km from international and domestic airports. This hotel comprises of 102 rooms and suites with all modern facilities and ample space. With easy access to Secunderabad main transit options, and within a 06 km radius of the Amee', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;3769 Sq.ft;Car Parking-200;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Valet Parking;Backup Power;Sound System;Stage', 350, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell ', 'Drinking;Caterer', '400', 'v1', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(4, 'h4', 'Lotus', 'Banquet', 10000, 1025, 'abc', 'An environmentally responsible hotel with various Eco initiatives, Manasarovar-The Fern, in Hyderabad is the most centrally located next to U.S.Consulate, Begumpet, Secunderabad, and situated in close proximity at a distance of 4km and 06 km from the Railway station and 38 Km from international and domestic airports. This hotel comprises of 102 rooms and suites with all modern facilities and ample space. With easy access to Secunderabad main transit options, and within a 06 km radius of the Amee', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;9729 Sq.ft;Car Parking-200;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Valet Parking;Backup Power;Sound System;Stage', 1500, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell ', 'Drinking;Caterer', '400', 'v1', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(5, 'h5', 'Crystal', 'Banquet', 10000, 1025, 'abc', 'An environmentally responsible hotel with various Eco initiatives, Manasarovar-The Fern, in Hyderabad is the most centrally located next to U.S.Consulate, Begumpet, Secunderabad, and situated in close proximity at a distance of 4km and 06 km from the Railway station and 38 Km from international and domestic airports. This hotel comprises of 102 rooms and suites with all modern facilities and ample space. With easy access to Secunderabad main transit options, and within a 06 km radius of the Amee', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;4529 Sq.ft;Car Parking-200;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Valet Parking;Backup Power;Sound System;Stage', 350, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell ', 'Drinking;Caterer', '400', 'v1', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(6, 'h6', 'Manda yadav reddy Garden & Function Hall', 'Function Hall', 10000, 0, 'abc', 'Manda Yadava Reddy Gardens is one of the highly reputed marriage halls located in Champapet, Hyderabad. The physical address of this marriage hall in Hyderabad is Garden Street, Sagar Road, Champapet, Hyderabad- 500004 Land Mark: Near Garden Street Bus Stand. Manda Yadava Reddy Gardens in Hyderabad can seat upto 4000 at once. Manda Yadava Reddy Gardens in Hyderabad hosts a number of social programs such as engagements, marriages, birthdays, naming ceremonies and other social events periodically', 'Power Backup;Sound System;Mike;Restroom;Stage', 1500, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell ', 'Drinking;DJ', '200', 'v2', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:49:55'),
	(7, 'h7', 'Vijay garden', 'Function Hall', 10000, 0, 'abc', 'Vijaya Garden Function Hall is one of the highly reputed marriage halls located in Golconda, Hyderabad. Vijaya Garden Function Hall in Hyderabad can seat upto 2000 at once. Vijaya Garden Function Hall in Hyderabad hosts a number of social programs such as marriages, naming ceremonies, birthdays, engagements and other social events from time to time. If you are looking for a marriage/event hall in Hyderabad, then please call NA. To receive pricing & availability for this function hall, please su', 'Power Backup;Sound System;Mike;Restroom;Stage', 2000, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell ', 'DJ;Decorator;Drinks;Caterer', '', 'v3', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:12'),
	(8, 'h8', 'Minerva garden', 'Function Hall', 10000, 0, 'abc', 'Minerva Gardens Function Hall is best for Wedding, Wedding Anniversary, Valentine\'s Day, Birthday Party, Bachelor Party, Brand Promotion, Class Reunion, Cocktail Dinner, Conference, Corporate Party, Christmas Party, Engagement, Fashion Show, Get Together, Kitty Party, Meeting, Pool Part, Training, Wedding Reception, New Year Part, Musical Concert, Corporate Offsite, Corporate Training, Family Get together, Freshers Party, Game Watch, Kids Birthday Party, Naming Ceremony, Pre Wedding Mehendi Part', 'Power Backup;Sound System;Mike;Restroom;Stage', 1000, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell ', 'DJ;Decorator;Drinks;Caterer', '', 'v4', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(9, 'h9', 'Mega function hall ', 'Function Hall', 10000, 0, 'abc', 'Mega Function Hall, Champapet, Hyderabad offers a beautiful and huge space for pre-wedding and wedding ceremonies. If you are hosting a larger gathering, this venue is just perfect. The venue is available with flexible time slots & offers in-house decorators. Convenient location and hospitable staff will surely make your special event a memorable affair. ', 'Power Backup;Sound System;Mike;Restroom;Stage', 200, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell ', 'DJ;Drinks', '', 'v5', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(10, 'h10', 'KNR Convention Hall', 'Function Hall', 10000, 0, 'abc', 'KNR Banquet & Conference  Hall in Champapet,Hyderabad listed under Function Hall Wedding with Address, contact number, reviews, Photos, Directions . View availability,photos,capacity,cost,design,prices,size,facilities .', 'Power Backup;Sound System;Mike;Restroom;Stage', 300, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell ', '', '', ' v6', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(11, 'h11', 'KNR Banquet Hall', 'Banquet', 10000, 0, 'abc', 'KNR Banquet & Conference  Hall in Champapet,Hyderabad listed under Function Hall Wedding with Address, contact number, reviews, Photos, Directions . View availability,photos,capacity,cost,design,prices,size,facilities .', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 300, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell ', 'Caterer;Drinks', '', 'v6', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(12, 'h12', 'MAK Club', 'Banquet', 10000, 1000, 'abc', 'Mak Club, Ranga Reddy, Hyderabad is equipped to plan every aspect of your wedding function carefully. The hall area with modern facilities has a decent capacity, allowing you to accommodate your guests comfortably. The hotel lets you get decorators from outside to help you uplift the way your venue looks and offer a visual treat. You can also get alcohol from outside to spruce up the liquor options. Choose a convenient time for your functions as the venue offers the flexibility of different time', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 250, '', 'Cocktail Party;Get Together;Wedding;Birthdays;Conference;Wedding Anniversary;Destination Weddings;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Annual Meet;Business Lunch/Dinner;Board Room Meeting;Corporate Trainings;Convention;Product Launch;Walk in Interview;Fresher/Farewell ', '', '', 'v7', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(13, 'h13', 'MAK Resort', 'Resort', 10000, 1250, 'abc', 'Mak Club, Ranga Reddy, Hyderabad is equipped to plan every aspect of your wedding function carefully. The hall area with modern facilities has a decent capacity, allowing you to accommodate your guests comfortably. The hotel lets you get decorators from outside to help you uplift the way your venue looks and offer a visual treat. You can also get alcohol from outside to spruce up the liquor options. Choose a convenient time for your functions as the venue offers the flexibility of different time', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 250, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', '', '', 'v7', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(14, 'h14', 'prime garden function hall', 'Garden', 10000, 0, 'abc', 'Jfs Prime Garden Function Hall is one of the sought after wedding halls located in Moti Nagar, Hyderabad. The physical address of this marriage hall in Hyderabad is JFS Garden Function Hall,8-3-228/678 1514/A Kalayan Nagar X Roads, Moti Nagar. Jfs Prime Garden Function Hall in Hyderabad can seat upto 1000 at once. Jfs Prime Garden Function Hall in Hyderabad hosts a number of social events such as engagements, marriages, birthdays, naming ceremonies and other social events through out the year.', 'Speakers;Veg&Non-veg;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 1000, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v8', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:25'),
	(15, 'h15', 'kothapaku yadhava reddy garden', 'Garden', 10000, 0, 'abc', 'Kothakapu Yadhava Reddy Gardens is one of the sought after marriage halls located in Champapet, Hyderabad. The physical address of this marriage hall in Hyderabad is Nirmala Nagar Colony, Karmanghat Road, Karmanghat, Hyderabad-500074. Kothakapu Yadhava Reddy Gardens in Hyderabad can seat upto 2500 at once. Kothakapu Yadhava Reddy Gardens in Hyderabad hosts a number of social gatherings such as marriages, naming ceremonies, birthdays, engagements and other social events periodically. If you are', 'Speakers;Veg&Non-veg;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 2500, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v9', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:37'),
	(16, 'h16', 'Lalitha Gardens', 'Garden', 10000, 0, 'abc', 'Bommidi Lalitha Gardens & Function Hall is located in LB Nagar. Bommidi Lalitha Gardens & Function Hall, LB Nagar has dining hall capacity 1000. Bommidi Lalitha Gardens & Function Hall, LB Nagar has reception hall capacity 1200 ( sitting ) to 2500 ( floating ). Bommidi Lalitha Gardens & Function Hall, LB Nagar is a veg and non veg function hall. ', 'Speakers;Veg&Non-veg;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 750, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v10', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(17, 'h17', 'Laxma reddy gardens', 'Garden', 10000, 0, 'abc', 'Laxma Reddy Gardens is one of the popular marriage halls located in Champapet, Hyderabad. The postal address of this wedding hall in Hyderabad is No. 9-4-165, Champapet, Hyderabad- 500035 Land Mark: Near Hanuman Temple. Laxma Reddy Gardens in Hyderabad can seat upto 1500 at once. Laxma Reddy Gardens in Hyderabad hosts a number of social gatherings such as marriages, engagements, naming ceremonies, birthdays and other social events through out the year. If you are looking for a marriage hall in', 'Speakers;Veg&Non-veg;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 1500, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Decorator;Drinks;Caterer', '', 'v11', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:47'),
	(18, 'h18', 'Manasa Gardens', 'Garden', 10000, 0, 'abc', 'Manasa Gardens is one of the famous wedding halls located in Champapet, Hyderabad. The postal address of this wedding hall in Hyderabad is Garden Street, Sagar Road, Champapet, Hyderabad – 500079. Manasa Gardens in Hyderabad can seat upto 1500 at once. Manasa Gardens in Hyderabad hosts a number of social programs such as marriages, engagements, naming ceremonies, birthdays and other social events regularly. If you are looking for a marriage venue in Hyderabad, then please call 914065344014/9192', 'Speakers;Veg&Non-veg;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 1500, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v12', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:55'),
	(19, 'h19', 'amr convention hall', 'Convention Cent', 10000, 0, 'abc', 'AMR Convention Hall 2 is located in LB Nagar. AMR Convention Hall 2, LB Nagar has dining hall capacity 200. AMR Convention Hall 2, LB Nagar has reception hall capacity 250 ( sitting ) to 400 ( floating ). AMR Convention Hall 2, LB Nagar is a veg and non veg function hall. ', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 250, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v13', '0', '2017-03-26 14:18:31', '0', '2017-03-28 20:59:03'),
	(20, 'h20', 'sri durga convention & banquet hall', 'Convention Cent', 10000, 0, 'abc', 'WE HAVE A GOOD CONVENTION CENTER WITH BANQUET HALL WITH GOOD PARKING FACILITY & NICE GARDENING....AT YOUR SERVICE ALWAYS...', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v14', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(21, 'h21', 'bhaskar\'s convention hall ', 'Convention Cent', 10000, 0, 'abc', '', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v15', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(22, 'h22', 'm convention center ', 'Convention Cent', 10000, 0, 'abc', 'M Convention Center is located in Boduppal. M Convention Center, Boduppal has dining hall capacity 1500. M Convention Center, Boduppal has reception hall capacity 2000 ( sitting ) to 4000 ( floating ). M Convention Center, Boduppal is a veg and non veg function hall.', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 2000, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v16', '0', '2017-03-26 14:18:31', '0', '2017-03-28 21:00:21'),
	(23, 'h23', 'jrc  convention center ', 'Convention Cent', 10000, 0, 'abc', 'The JRC Convention Centre located in Jubilee Hill, Hyderabad has Wedding Hotels, Banquet Halls, Wedding Lawns and Mantapa / Convention Hall. Hall 1 can accommodate upto 1200 guests in seating and 1800 guests in floating. Lawn can accommodate upto 2800 guests in seating and 4200 guests in floating.', 'Speakers;Veg&Non-veg;Air Conditioning;Wifi;Lift;Wheel Chair&Ramp;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 2000, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Baby Shower;Naming Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell', 'DJ;Drinks', '', 'v17', '0', '2017-03-26 14:18:31', '0', '2017-03-28 21:00:30'),
	(24, 'h24', 'Mrugavani Resort and Spa', 'Resort', 10000, 0, 'abc', 'Nestled in the City of Pearls, well known for its magnificent palaces, mosques and tombs, Hyderabad, Mrugavani resorts and spa is an alluring property that offers recreation and relief at its best. One can enjoy and have their leisure time at the property that offers a refreshing treat to visit', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', 'Caterer', '', 'v18', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(25, 'h25', 'Golkonda Resorts & Spa', 'Resort', 10000, 0, 'abc', 'Endearingly called the City of Pearls, located in the charming city of Hyderabad. Golkonda Resorts and Spa is a 4 star property, located right next to the picturesque Gandipet Lake. It is a classic property that offers sophisticated fusion of exclusive elegance and warm hospitality. One can also vis', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', 'Caterer', '', 'v19', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(26, 'h26', 'Button Eyes Resort', 'Resort', 10000, 0, 'abc', 'Button Eyes Resort offers pet-friendly accommodation at at Tolkatta Village Moinabad, Hyderabad. The resort has a year-round outdoor pool, children\'s playground and terrace, and guests can enjoy a meal at the restaurant. Free private parking is available on site.', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', 'Caterer', '', 'v20', '0', '2017-03-26 14:18:31', '0', '2017-03-28 21:00:46'),
	(27, 'h27', 'Countryside Resorts', 'Resort', 10000, 0, 'abc', 'Featuring free WiFi, Countryside Resorts offers accommodation in Hyderabad, 10 km from Golkonda Fort. The resort has an outdoor pool and terrace, and guests can enjoy a meal at the restaurant.Each room includes a flat-screen TV. All rooms are equipped with a private bathroom.Nehru Zoological Park is 12 km from Countryside Resorts, while ISB is 12 km away. The nearest airport is Rajiv Gandhi International Airport, 14 km from Countryside Resorts.We speak your language! Countryside Resorts has been', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', 'Caterer', '', 'v21', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31'),
	(28, 'h28', 'D Lake View Resort', 'Resort', 10000, 0, 'abc', 'Explode Season-2 Nye 2015 At D-lake View Resort Featuring Four Amazing Djs And Offering The Guests A Musical Treat This New Year\\\'s Eve Is Here To Enthrall You This New Year. Explode Season-2 Nye 2015 At D-lake View Resort Would Have A Live Performance And Music By The Following Artists Who Would Keep You On Your Toes And Hooked To The Dance Floor.', 'Speakers;Veg&Non-veg;Swimming Pool;Air Conditioning;Wifi;Rooms;Mic;Projector;Drinks;Backup Power;Sound System;Stage', 0, '', 'Get Together;Wedding;Birthdays;Wedding Anniversary;Engagement;Kitty Party;Sangeet Ceremony;Business Lunch/Dinner;Product Launch;Fresher/Farewell;Destination  Weddings ', 'Caterer', '', 'v22', '0', '2017-03-26 14:18:31', '0', '2017-03-26 14:18:31');
/*!40000 ALTER TABLE `hall` ENABLE KEYS */;


-- Dumping structure for table venue4me.hall_booking
CREATE TABLE IF NOT EXISTS `hall_booking` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(50) NOT NULL,
  `cid` varchar(10) NOT NULL,
  `hid` varchar(10) NOT NULL,
  `from_date` datetime NOT NULL,
  `to_date` datetime NOT NULL,
  `invoice_num` varchar(50) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_of_booking` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `booking_id` (`booking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.hall_booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `hall_booking` DISABLE KEYS */;
INSERT INTO `hall_booking` (`Id`, `booking_id`, `cid`, `hid`, `from_date`, `to_date`, `invoice_num`, `created_by`, `created_on`, `updated_by`, `updated_on`, `date_of_booking`) VALUES
	(1, 'B1', 'C1', 'h8', '2017-03-30 00:00:00', '2017-03-30 18:00:00', 'I1', '', '2017-03-28 16:12:57', '', '2017-03-28 16:13:31', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `hall_booking` ENABLE KEYS */;


-- Dumping structure for table venue4me.hall_favourite
CREATE TABLE IF NOT EXISTS `hall_favourite` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` varchar(50) NOT NULL,
  `cid` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.hall_favourite: ~0 rows (approximately)
/*!40000 ALTER TABLE `hall_favourite` DISABLE KEYS */;
/*!40000 ALTER TABLE `hall_favourite` ENABLE KEYS */;


-- Dumping structure for table venue4me.hall_multimedia
CREATE TABLE IF NOT EXISTS `hall_multimedia` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` varchar(10) NOT NULL,
  `photos` varchar(200) NOT NULL,
  `videos` varchar(200) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(200) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.hall_multimedia: ~25 rows (approximately)
/*!40000 ALTER TABLE `hall_multimedia` DISABLE KEYS */;
INSERT INTO `hall_multimedia` (`Id`, `hid`, `photos`, `videos`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'h2', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(2, 'h3', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(3, 'h4', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(4, 'h5', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(5, 'h6', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(6, 'h7', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(7, 'h8', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(8, 'h9', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(9, 'h10', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(10, 'h11', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(11, 'h12', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(12, 'h13', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(13, 'h14', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(14, 'h15', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(15, 'h16', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(16, 'h17', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(17, 'h18', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(18, 'h19', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(19, 'h20', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(20, 'h21', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(21, 'h22', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(22, 'h23', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(23, 'h24', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(24, 'h25', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(25, 'h26', 'images\\img4.jpg', 'NA', '', '2017-03-11 20:06:23', '', '2017-03-11 20:06:23'),
	(26, 'h1', 'images\\img4.jpg', 'NA', '', '2017-03-26 14:22:58', '', '2017-03-26 14:22:58');
/*!40000 ALTER TABLE `hall_multimedia` ENABLE KEYS */;


-- Dumping structure for table venue4me.lookup
CREATE TABLE IF NOT EXISTS `lookup` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `l_key` varchar(50) NOT NULL DEFAULT '0',
  `value` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `l_key` (`l_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.lookup: ~0 rows (approximately)
/*!40000 ALTER TABLE `lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lookup` ENABLE KEYS */;


-- Dumping structure for table venue4me.seating_type
CREATE TABLE IF NOT EXISTS `seating_type` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `packs` varchar(10) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `hid` (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.seating_type: ~0 rows (approximately)
/*!40000 ALTER TABLE `seating_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `seating_type` ENABLE KEYS */;


-- Dumping structure for table venue4me.slot_lookup
CREATE TABLE IF NOT EXISTS `slot_lookup` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `slot_id` varchar(10) NOT NULL,
  `value` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `slot_id` (`slot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.slot_lookup: ~0 rows (approximately)
/*!40000 ALTER TABLE `slot_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `slot_lookup` ENABLE KEYS */;


-- Dumping structure for table venue4me.user_login
CREATE TABLE IF NOT EXISTS `user_login` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `pswd` varchar(150) NOT NULL,
  `uid` varchar(10) NOT NULL,
  `salt` varchar(150) NOT NULL,
  `usertype` varchar(30) NOT NULL,
  `status` varchar(15) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `username` (`username`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.user_login: ~3 rows (approximately)
/*!40000 ALTER TABLE `user_login` DISABLE KEYS */;
INSERT INTO `user_login` (`Id`, `username`, `pswd`, `uid`, `salt`, `usertype`, `status`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'v@g.com', '12345678', '', '', 'customer', 'activated', 'self', '2017-03-16 11:36:38', 'self', '2017-03-16 11:39:13'),
	(2, 's@g.com', '12345678', 'v4', '', 'vendor', 'active', '', '2017-03-17 01:51:24', '', '2017-03-28 18:42:25'),
	(3, 'k@v.com', '12345678', '', '', 'vendor', 'active', 'self', '2017-03-18 08:37:05', 'self', '2017-03-18 08:40:54');
/*!40000 ALTER TABLE `user_login` ENABLE KEYS */;


-- Dumping structure for table venue4me.vendor
CREATE TABLE IF NOT EXISTS `vendor` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` varchar(10) NOT NULL DEFAULT '0',
  `vname` varchar(50) NOT NULL,
  `mgmt_contact` varchar(50) NOT NULL,
  `mgmt_landline` varchar(50) NOT NULL,
  `mgmt_email` varchar(50) NOT NULL,
  `manager_name` varchar(50) NOT NULL,
  `manager_contact` varchar(50) NOT NULL,
  `no_of_halls` int(3) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `vid` (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.vendor: ~22 rows (approximately)
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` (`Id`, `vid`, `vname`, `mgmt_contact`, `mgmt_landline`, `mgmt_email`, `manager_name`, `manager_contact`, `no_of_halls`, `featured`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
	(1, 'v1', 'Manas Sarovar the Fern', '9848022330', '406262888', 'Samhyd@fernhotels.com', 'XYZ', '9848022330', 5, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(2, 'v2', 'Manda yadav reddy garden', '9246343979', '4065344014', 'abc@xyz.com', 'ABC', '9246343979', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(3, 'v3', 'Vijay garden', '', '040-23511650', 'bcd@xyz.com', 'BCD', '040-23511650', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(4, 'v4', 'Minerva garden', '9440345557', '040 6559 9425', 'cde@xyz.com', 'CDE', '9440345557', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-28 19:12:12'),
	(5, 'v5', 'Mega function hall ', '', '040 2407 5494', 'def@xyz.com', 'DEF', '040 2407 5494', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(6, 'v6', 'Knr convention hall & banquet hall', '88012 05678', '040 2407 5494', 'efg@xyz.com', 'EFG', '88012 05678', 2, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(7, 'v7', 'MAK Club & Resort', '99499 65611', '4023339595', 'fgh@xyz.com', 'FGH', '99499 65611', 2, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(8, 'v8', 'prime garden function hall', '9394861232', '040 2403 5490', 'ghi@xyz.com', 'GHI', '9394861232', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(9, 'v9', 'kothapaku yadhava reddy garden', '', '4024078777', 'hij@xyz.com', 'HIJ', '4024078777', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(10, 'v10', 'Lalitha Gardens', '9849019577', '', 'ijk@xyz.com', 'IJK', '9849019577', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(11, 'v11', 'Laxma reddy gardens', '9849231328', '', 'jkl@xyz.com', 'JKL', '9849231328', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(12, 'v12', 'Manasa Gardens', '9246343979', '4065344014', 'klm@xyz.com', 'KLM', '9246343979', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(13, 'v13', 'amr convention hall', '98661 02361', '', 'lmn@xyz.com', 'LMN', '98661 02361', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(14, 'v14', 'sri durga convention & banquet hall', '077999 94439', '', 'mno@xyz.com', 'MNO', '077999 94439', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(15, 'v15', 'bhaskar\'s convention hall ', '', '040 2422 9900', 'nop@xyz.com', 'NOP', '040 2422 9900', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(16, 'v16', 'm convention center ', '', '040 3301 5425', 'opq@xyz.com', 'OPQ', '040 3301 5425', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(17, 'v17', 'jrc  convention center ', ' +919963472374 ', '040 4554 9999', 'pqr@xyz.com', 'PQR', ' +919963472374 ', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(18, 'v18', 'Mrugavani Resort and Spa', '083339 22955', '', 'qrs@xyz.com', 'QRS', '083339 22955', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(19, 'v19', 'Golkonda Resorts & Spa', '', '040 30696969', 'rst@xyz.com', 'RST', '040 30696969', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(20, 'v20', 'Button Eyes Resort', '090105 70780', '', 'stu@xyz.com', 'STU', '090105 70780', 1, 'Yes', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(21, 'v21', 'Countryside Resorts', '080197 15189', '', 'tuv@xyz.com', 'TUV', '080197 15189', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29'),
	(22, 'v22', 'D Lake View Resort', '089780 35599', '', 'uvw@xyz.com', 'UVW', '089780 35599', 1, 'No', '', '2017-03-25 22:14:29', '', '2017-03-25 22:14:29');
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;


-- Dumping structure for table venue4me.vendor_category
CREATE TABLE IF NOT EXISTS `vendor_category` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table venue4me.vendor_category: ~0 rows (approximately)
/*!40000 ALTER TABLE `vendor_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendor_category` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
