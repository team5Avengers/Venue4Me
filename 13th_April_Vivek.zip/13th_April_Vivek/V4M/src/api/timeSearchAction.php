<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class timeSearchAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
        $json = $request->getBody();
		$data = json_decode($json, TRUE);
        $info = $data[0]['info'];
        //echo key($data[1]);
        $where = "";
		for($i=1;$i<sizeof($data);$i=$i+1){
            $slots = explode(';',$data[$i][key($data[$i])]);
            foreach($slots as $slot){
                $slot_array[] = 'slotid LIKE "%'.$slot.'%"';
            }
            $slot_query = implode(' OR ',$slot_array);
            $date_query = '(date="'.key($data[$i]).'" AND ('.$slot_query.'))';
            $date_array[] = $date_query;
        }
        $where = implode(' OR ',$date_array);
        echo $where;
		$query="select hid from booking_avail where ".$where;
		$stmt = $connection->prepare($query);
				$stmt->execute();
        $res = $stmt->get_result();
				$row = $res->fetch_assoc();
        if(count($row==0)){
            
        }
        else{
            
        }
			//echo json_encode($row);
   }
}

?>