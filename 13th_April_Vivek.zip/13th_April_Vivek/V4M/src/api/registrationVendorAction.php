<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class registrationVendorAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		date_default_timezone_set('UTC');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$json = $request->getBody();
		$obj = json_decode($json, TRUE);
		$vname= $obj["vendorName"];
		$email= $obj["email"];
		$userType= $obj["userType"];
		$contact= $obj["contact"];
		$password =$obj["password"];
		$numHalls=$obj["numHalls"];
		$status ="wait";
		$vid="";
		$id="";
		$salt="";
		$date ;
		$createdBy="self";
		$state="";
		//$date1=$date->date;
		try{
				$query="insert into vendor values(?,?,?,?,?,?,?,?,?)";
				$stmt = $connection->prepare($query);
				if($stmt){
					$stmt->bind_param("isssisisi",$id,$vid,$vname,$contact,$numHalls,$createdBy,$date,$createdBy,$date);
					$stmt->execute();
					
					$sql="insert into user_login(id,username,pswd,salt,userType,status,created_by,created_on,updated_by,updated_on)values(?,?,?,?,?,?,?,?,?,?)";
					$sqlStmt = $connection->prepare($sql);
					if($sqlStmt){
						$sqlStmt->bind_param("issssssisi",$id,$email,$password,$salt,$userType,$status,$createdBy,$date,$createdBy,$date);
						$sqlStmt->execute();
					}else{
						$rolQuery="delete from vendor where contact=:contact";
						$rolStmt = $connection->prepare($rolQuery);
						$rolStmt->bindParam("contact", $contact);
						$rolStmt->execute();
						$state=array('state'=>'Transaction Rolled Back');
							return json_encode($state);
					}
				}else{return "failed";}
				$connection=null;
				$state=array('state'=>'Success');
				return json_encode($state);
		}catch(PDOException $e) {
			$state=array('state'=>$e->getMessage());
			return json_encode($state);
		}
   }
}

?>