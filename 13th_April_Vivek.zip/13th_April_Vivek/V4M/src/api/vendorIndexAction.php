<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class vendorIndexAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
			$conn=new dbConnection();
		    $connection=$conn->connect_db();
			$json = $request->getBody();
		
			$data = json_decode($json, TRUE);
			$vid=$data['id'];
            $status="booked";
		$query='select * from hall h INNER JOIN hall_booking hb ON h.hid=hb.hid INNER JOIN booking_avail ba ON h.hid=ba.hid where h.vid=? and ba.status="booked" and ba.date>=CURDATE()';
		$stmt = $connection->prepare($query);
				$stmt->bind_param("s", $vid);
						$stmt->execute();
			$res = $stmt->get_result();
			//$row = $res->fetch_assoc();
			$row1=array();
				while($row = $res->fetch_assoc()){
					array_push($row1, $row);
				}		
			return json_encode($row1);
   }
}

?>