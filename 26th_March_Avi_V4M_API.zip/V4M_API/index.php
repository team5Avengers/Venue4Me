<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require './vendor/autoload.php';
require_once('./dbConf.php');

$app = new \Slim\App;
$app->post('/hello', function (Request $request, Response $response) {
    //$name = $request->getAttribute('name');
	 $json = $request->getBody();
    //$data = json_decode($json, true);
	$obj = json_decode($json, TRUE);
$fname= $obj["fname"];
$lname =$obj["lname"];
	//echo "\n".$json."\n";
   /*  $response->getBody()->write("Hello, $name"); */
   $conn=new dbConnection();
   $connection=$conn->connect_db();
   $query="insert into test(fname,lname) values(?,?)";
    $stmt = $connection->prepare($query);
	$stmt->bind_param("ss",$fname,$lname);
	$stmt->execute();
    return "OK";
});

$app->get('/select', function (Request $request, Response $response) {
    //$name = $request->getAttribute('name');

	//echo "\n".$json."\n";
   /*  $response->getBody()->write("Hello, $name"); */
   $conn=new dbConnection();
   $connection=$conn->connect_db();
   $query="select * from test";
   $result = $connection->query($query);
 while ($row = $result->fetch_assoc()){
 
$data[] = $row;
 echo json_encode($data);
 }
    return "OK";
});
$app->run();