<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class vendorObjectAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		   $conn=new dbConnection();
   $connection=$conn->connect_db();
		$json = $request->getBody();
		//echo $json;
		$data = json_decode($json, TRUE);
		$vid=$data['id'];
		
		$query="select * from vendor where vid=?";
		$stmt = $connection->prepare($query);
				$stmt->bind_param("s", $vid);
						$stmt->execute();
			$res = $stmt->get_result();
				$row = $res->fetch_assoc();		
			return json_encode($row);
   }
}

?>