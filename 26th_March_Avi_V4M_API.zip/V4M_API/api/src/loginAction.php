<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;

require_once'/../utils/connection.php';

class loginAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
   $conn=new dbConnection();
   $connection=$conn->connect_db();
		$json = $request->getBody();
		$obj = json_decode($json, TRUE);
		$userName= $obj["email"];
		$password =$obj["password"];
		$query="select count(*) as cnt,usertype,status,username from user_login where username=? and pswd=?";
		try{
				$stmt = $connection->prepare($query);
				$stmt->bind_param("ss", $userName,$password);
	//$stmt->bind_param("s", $password);
				$stmt->execute();
				$res = $stmt->get_result();
				$row = $res->fetch_assoc();
				if($row['cnt']==1){
					return json_encode($row);
				}else
					$failure = array('status' => 'failed');
					return json_encode($failure);
		}catch(PDOException $e) {
			return json_encode($e->getMessage());
		}
   }
}

?>