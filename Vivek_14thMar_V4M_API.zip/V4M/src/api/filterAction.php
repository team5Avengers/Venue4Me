<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class filterAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$paramValue = $request->getQueryParams();
       $query_array = array();
       $cat="";$price="";$bprice="";$feat="";$event="";$local="";$localWhere="";
		foreach ($paramValue as $key => $value)
		{
            if($key=='locality'){
                $local = explode(',', $value);
                foreach ($local as $val)
                {
                    if ($val != '')
                    { $local_array[] = 'locality = "'.$val.'"';}
                }
            }
			if($key=='categories'){
                $cat = explode(',', $value);
                foreach ($cat as $val)
                {
                    if ($val != '')
                    { $cat_array[] = 'category = "'.$val.'"';}
                }
            }
            if($key=='price'){
                $price = explode(',',$value);
                foreach ($price as $val)
                {
                    if ($val != '')
                    {
                        $priceRange = explode('-',$val);
                        $price_array[] = 'booking_amt BETWEEN '.$priceRange[0].' AND '.$priceRange[1];
                    
                    }
                }
            }
            if($key=='bprice'){
                $bprice = explode(',',$value);
                foreach ($bprice as $val)
                {
                    if ($val != '')
                    { 
                        $bpriceRange = explode('-',$val);
                        $bprice_array[] = 'booking_amt BETWEEN '.$bpriceRange[0].' AND '.$bpriceRange[1];
                    }
                }
            }
            if($key=='features'){
                $feat = explode(',',$value);
                foreach ($feat as $val)
                {
                    if ($val != '')
                    { $feat_array[] = 'features = "'.$val.'"';}
                }
            }
            if($key=='events'){
                $event = explode(',',$value);
                foreach ($event as $val)
                {
                    if ($val != '')
                    { $event_array[] = 'events = "'.$val.'"';}
                }
            }
		}
        if($cat!="")
        {
            $whereStr = implode(' OR ', $cat_array);
        }
        if($price!="")
        {
            $whereStr = '('.$whereStr.')'.' AND '.'('.implode(' OR ', $price_array).')';
        }
        if($bprice!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $bprice_array).')';
        }
        if($feat!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $feat_array).')';
        }
        if($event!="")
        {
            $whereStr = $whereStr.' AND ('.implode(' OR ', $event_array).')';
        }
        if($local!=""){
            $localWhere = implode(' OR ',$local_array);
            $hall_query = 'SELECT aid from address_info where '.$localWhere;
            //echo $hall_query;
            try{
				$stmt = $connection->prepare($hall_query);
				$stmt->execute();
				$res = $stmt->get_result();
                $myArray1 = array();
                while($row = $res->fetch_array(MYSQL_ASSOC)) {
                    $myArray1[] = $row;
                }
                //print_r $myArray1;
                $halls_array="";
                foreach ($myArray1 as $key=>$val)
                {
                    if ($val != '')
                    { $halls_array[] = 'hid = "'.$val['aid'].'"';}
                }
                if($halls_array!='')
                    $hallWhereStr = implode(' OR ', $halls_array);
                else
				    $hallWhereStr = "";
		      }catch(PDOException $e) {
			     return json_encode($e->getMessage());
		      }
        }
       if($hallWhereStr!=''){
            $query='SELECT hid,hname,booking_amt,hall_shortdesc FROM hall WHERE ' .$hallWhereStr.' AND '.$whereStr;
            //echo $query;
            try{
                    $stmt = $connection->prepare($query);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    $myArray = array();
                    while($row = $res->fetch_array(MYSQL_ASSOC)) {
                        $myArray[] = $row;
                    }
                    return $response->withJson($myArray);
            }catch(PDOException $e) {
                return json_encode($e->getMessage());
            }
       }
       else{
           $error = array('error_message'=>'No results found','count'=>0);
           return json_encode($error);
       }
       //echo $whereStr;
       
   }
}

?>