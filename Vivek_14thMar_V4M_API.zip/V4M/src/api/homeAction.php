<?PHP
use \Interop\Container\ContainerInterface as ContainerInterface;


require_once'/../utils/connection.php';

class homeAction 
{
  protected $container;
   
   public function __construct(ContainerInterface $container) {
       $this->container = $container;
   }
   
   public function __invoke($request, $response, $args) {
        // your code
        // to access items in the container... $this->container->get('');
		$conn=new dbConnection();
		$connection=$conn->connect_db();
		$paramValue = $request->getQueryParams();
       $query_array = array();
	   //WE GET LOCALITY ,PACKS ,DAY, EVENT CATEGORY
       $cat="";$packs="";$day1="";$locality="";$event="";$local="" ;
		foreach ($paramValue as $key => $value)
		{
            if($key=='locality'){
                $local = $value;
            }
            if($key=='packs'){
                $packs = $value;
            }
		}
        if($local!="" && $packs!=1){
		
          ///For sending entire data lets dicuss and finalize  //$hall_query = 'SELECT * from b.hall,a.address_info,c.hall_multimedia where a.hid=b.hid and b.hid=c.hid and b.category=' .$event.' and b.capacity='.$packs. ' and a.locality=' .$local. ';
            $hall_query='SELECT a.hid,a.hname,a.category,a.capacity,a.booking_amt,a.hall_shortdesc,b.locality,c.photos FROM hall a INNER JOIN address_info b ON a.hid=b.aid INNER JOIN hall_multimedia c ON a.hid=c.hid WHERE a.capacity<="'.$packs.'" and b.locality="'.$local.'"';
			//echo $hall_query;
				 try{
									$stmt = $connection->prepare($hall_query);
									$stmt->execute();
									$res = $stmt->get_result();
									$myArray = array();
									while($row = $res->fetch_array(MYSQL_ASSOC)) {
										$myArray[] = $row;
										//$myArray[i] = $row;//For sending entire data lets dicuss and finalize
									}
									//Sending clubbed data for both hall and address_info using hid
									return $response->withJson($myArray);
							}catch(PDOException $e) {
								return json_encode($e->getMessage());
							}
        }
       
       
   }
}

?>