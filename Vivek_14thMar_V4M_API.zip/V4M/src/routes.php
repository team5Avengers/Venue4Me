<?php

require "/api/filterAction.php";
require "/api/homeAction.php";
require "/api/loginAction.php";
require "/api/registrationAction.php";
require "/api/registrationVendorAction.php";
require "/api/localityAction.php";
require "/api/vendorObjectAction.php";
// Routes
$app->post('/login', \loginAction::class);
$app->post('/registration', \registrationAction::class);
$app->post('/registrationVendor', \registrationVendorAction::class);
$app->post('/vendorObject', \vendorObjectAction::class);

$app->get('/filters', \filterAction::class);
$app->get('/localities', \localityAction::class);
$app->get('/halls', \homeAction::class);

?>
